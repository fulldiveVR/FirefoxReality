// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

#ifndef OVR_CALAPPLICATIONPROPOSED_H
#define OVR_CALAPPLICATIONPROPOSED_H

#include "OVR_Platform_Defs.h"
#include "OVR_Types.h"

typedef struct ovrCalApplicationProposed *ovrCalApplicationProposedHandle;

OVRP_PUBLIC_FUNCTION(ovrID) ovr_CalApplicationProposed_GetID(const ovrCalApplicationProposedHandle obj);

#endif
