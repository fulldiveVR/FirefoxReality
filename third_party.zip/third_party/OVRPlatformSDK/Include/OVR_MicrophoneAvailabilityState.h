// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

#ifndef OVR_MICROPHONEAVAILABILITYSTATE_H
#define OVR_MICROPHONEAVAILABILITYSTATE_H

#include "OVR_Platform_Defs.h"
#include <stdbool.h>

typedef struct ovrMicrophoneAvailabilityState *ovrMicrophoneAvailabilityStateHandle;

OVRP_PUBLIC_FUNCTION(bool) ovr_MicrophoneAvailabilityState_GetMicrophoneAvailable(const ovrMicrophoneAvailabilityStateHandle obj);

#endif
