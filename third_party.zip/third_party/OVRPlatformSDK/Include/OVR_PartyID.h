// This file was @generated with LibOVRPlatform/codegen/main. Do not modify it!

#ifndef OVR_PARTYID_H
#define OVR_PARTYID_H

#include "OVR_Platform_Defs.h"
#include "OVR_Types.h"

typedef struct ovrPartyID *ovrPartyIDHandle;

OVRP_PUBLIC_FUNCTION(ovrID) ovr_PartyID_GetID(const ovrPartyIDHandle obj);

#endif
