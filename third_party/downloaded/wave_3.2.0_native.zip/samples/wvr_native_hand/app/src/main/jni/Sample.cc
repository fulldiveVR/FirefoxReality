#include <wvr/wvr_types.h>
#include <wvr/wvr_events.h>
#include <wvr/wvr_device.h>
#include <wvr/wvr_render.h>
#include <wvr/wvr_projection.h>
#include <wvr/wvr_hand.h>

#include <EGL/egl.h>
#include <GLES3/gl31.h>

#include <atomic>
#include <map>
#include <jni.h>

#include "Sample.h"
#include "log.h"

#define VR_MAX_CLOCKS 200
// Return micro second.  Should always positive because now is bigger.
#define timeval_subtract(now, last) \
    ((now.tv_sec - last.tv_sec) * 1000000LL + now.tv_usec - last.tv_usec)

// -----------------------------------------------------------
static const char* GetGestureTypeName(WVR_HandGestureType type) {
    static const std::map<WVR_HandGestureType, const char*> table {
                {WVR_HandGestureType_Invalid, "Invalid"},
                {WVR_HandGestureType_Unknown, "Unknown"},
                {WVR_HandGestureType_Fist, "Fist"},
                {WVR_HandGestureType_Five, "Five"},
                {WVR_HandGestureType_OK, "OK"},
                {WVR_HandGestureType_ThumbUp, "ThumbUp"},
                {WVR_HandGestureType_IndexUp, "IndexUp"},
        };
        auto it = table.find(type);
        if (it == table.end()) {
            LOGW("Unknown WVR_HandGestureType = %d", type);
            return "";
        }
        return table.at(type);
}

static const char* toString(WVR_FingerType type) {
    static const std::map<WVR_FingerType, const char*> table {
            {WVR_FingerType_Thumb, "Thumb"},
            {WVR_FingerType_Index, "Index"},
            {WVR_FingerType_Middle, "Middle"},
            {WVR_FingerType_Ring, "Ring"},
            {WVR_FingerType_Pinky, "Pinky"},
    };
    auto it = table.find(type);
    if (it == table.end()) {
        LOGW("Unknown WVR_FingerType = %d", type);
        return "";
    }
    return table.at(type);
}

static const char* toString(WVR_HandPoseType type) {
    static const std::map<WVR_HandPoseType, const char*> table {
            {WVR_HandPoseType_Invalid, "Invalid"},
            {WVR_HandPoseType_Pinch, "Pinch"},
    };
    auto it = table.find(type);
    if (it == table.end()) {
        LOGW("Unknown WVR_HandPoseType = %d", type);
        return "";
    }
    return table.at(type);
}
std::string format(const char* fmt, ...) {
    int size = 512;
    char* buffer = new char[size];
    va_list vl;
    va_start(vl, fmt);
    int nsize = vsnprintf(buffer, size, fmt, vl);
    if (size <= nsize) {
        delete[] buffer;
        buffer = 0;
        buffer = new char[nsize+1];
        nsize = vsnprintf(buffer, size, fmt, vl);
    }
    std::string ret(buffer);
    va_end(vl);
    delete[] buffer;
    return ret;
}

static std::string toString(const WVR_Vector3f_t& data) {
    return format("vec(%.4f, %.4f, %.4f)", data.v[0], data.v[1], data.v[2]);
}

static std::string toString(const WVR_Quatf_t& data) {
    return format("quat(%.4f, %.4f, %.4f, %.4f)", data.w, data.x, data.y, data.z);
}

static void dump(const WVR_FingerState& data) {
    LOGI("%-16s %s", "JONIT 1", toString(data.joint1).c_str());
    LOGI("%-16s %s", "JONIT 2", toString(data.joint2).c_str());
    LOGI("%-16s %s", "JONIT 3", toString(data.joint3).c_str());
    LOGI("%-16s %s", "TIP", toString(data.tip).c_str());
}

static void dump(const WVR_HandPoseState& pose) {
    switch (pose.base.type) {
        default:
            LOGI("no special pose");
            break;
        case WVR_HandPoseType_Pinch: {
            LOGI("%-16s %s", "Pinch origin", toString(pose.pinch.origin).c_str());
            LOGI("%-16s %s", "Pinch direction", toString(pose.pinch.direction).c_str());
            LOGI("%-16s %s", "Pinch finger", toString(pose.pinch.finger));
            LOGI("%-16s %f", "Pinch strength", pose.pinch.strength);
            break;
        }
    }
}

static void dump(const WVR_HandSkeletonState& hand) {
    LOGI("%-16s %s", "Hand position", toString(hand.wrist.rawPose.position).c_str());
    LOGI("%-16s %s", "Hand rotation", toString(hand.wrist.rawPose.rotation).c_str());
    LOGI("%-16s %s", "Hand linearVel", toString(hand.wrist.velocity).c_str());
    LOGI("%-16s %s", "Hand angularVel", toString(hand.wrist.angularVelocity).c_str());
    LOGI("%-16s", "Thumb");
    dump(hand.thumb);
    LOGI("%-16s", "Index");
    dump(hand.index);
    LOGI("%-16s", "Middle");
    dump(hand.middle);
    LOGI("%-16s", "Ring");
    dump(hand.ring);
    LOGI("%-16s", "Pinky");
    dump(hand.pinky);
}
// -----------------------------------------------------------

Sample::Sample()
        : mScene(NULL)
        , mLeftEyeQ(NULL)
        , mRightEyeQ(NULL) {
    memset(mTxtEvent, 0, 64);
    strncpy(mTxtEvent, "Event Type", 63);
}

Sample::~Sample() {}

bool Sample::Init() {
    LOGI("Init");

    uint32_t width, height;
    WVR_GetRenderTargetSize(&width, &height);
    LOGI("WVR_GetRenderTargetSize: width=%d, height=%d", width, height);
    mScene = new Empty(width, width);
    mScene->setEnable(true);

    mLeftEyeQ = WVR_ObtainTextureQueue(WVR_TextureTarget_2D,
                                       WVR_TextureFormat_RGBA,
                                       WVR_TextureType_UnsignedByte,
                                       width, height, 0);

    LOGI("mLeftEyeQ size: %d", WVR_GetTextureQueueLength(mLeftEyeQ));
    for (int i = 0; i < WVR_GetTextureQueueLength(mLeftEyeQ); i++) {
        FrameBufferObject* fbo = new FrameBufferObject(
                (uintptr_t)WVR_GetTexture(mLeftEyeQ, i).id,
                width, height);
        if (fbo->hasError()) {
            LOGI("fbo for mLeftEyeQ has error");
            return false;
        }
        mLeftEyeFBO.push_back(fbo);
    }

    mRightEyeQ = WVR_ObtainTextureQueue(WVR_TextureTarget_2D,
                                        WVR_TextureFormat_RGBA,
                                        WVR_TextureType_UnsignedByte,
                                        width, height, 0);

    LOGI("mRightEyeQ size: %d", WVR_GetTextureQueueLength(mRightEyeQ));
    for (int i = 0; i < WVR_GetTextureQueueLength(mRightEyeQ); i++) {
        FrameBufferObject* fbo;

        fbo = new FrameBufferObject((uintptr_t)WVR_GetTexture(mRightEyeQ, i).id, width, height);
        if (fbo->hasError()) {
            LOGI("fbo for mRightEyeQ has error");
            return false;
        }
        mRightEyeFBO.push_back(fbo);
    }

    mText = new Text(0.05f);
    mText->setEnable(true);

    bHandTracking = (WVR_StartHandTracking() == WVR_Success);
    bHandGesture = (WVR_StartHandGesture() == WVR_Success);

    if (bHandGesture) {
        LOGI("Start Hand Gesture Success");
        snprintf(mTxtGesture, 63, "Start Gesture successed");
    } else {
        LOGE("Start Hand Gesture failed");
        snprintf(mTxtGesture, 63, "Start Gesture failed");
    }

    if (bHandTracking) {
        LOGI("Start Hand Tracking Success");
        snprintf(mTxtTracking, 63, "Start Tracking successed");
    } else {
        LOGE("Start Hand Tracking failed");
        snprintf(mTxtTracking, 63, "Start Tracking failed");
    }

    return true;
}

void Sample::Shutdown() {
    if (bHandTracking) {
        WVR_StopHandTracking();
    }

    if (bHandGesture) {
        WVR_StopHandGesture();
    }

    LOGI("Shutdown");
    if (mScene != NULL) {
        mScene->setEnable(false);
        delete mScene;
    }
    mScene = NULL;

    if (mLeftEyeQ != 0) {
        for (int i = 0; i < WVR_GetTextureQueueLength(mLeftEyeQ); i++) {
            delete mLeftEyeFBO.at(i);
        }
        WVR_ReleaseTextureQueue(mLeftEyeQ);
    }

    if (mRightEyeQ != 0) {
        for (int i = 0; i < WVR_GetTextureQueueLength(mRightEyeQ); i++) {
            delete mRightEyeFBO.at(i);
        }
        WVR_ReleaseTextureQueue(mRightEyeQ);
    }
}

bool Sample::HandleEvent() {
    // Process WVR events
    WVR_Event_t event;
    while(WVR_PollEventQueue(&event)) {
        //LOGI("HandleEvent (%d)", event.common.type);
        switch(event.common.type) {
            default:
                break;

            case WVR_EventType_Quit:
                return true;

            case WVR_EventType_HandTracking_Abnormal:
                if (bHandTracking) {
                    LOGI("Tracking Abnormal [%" PRId64 "]", event.common.timestamp);
                    snprintf(mTxtEvent, 63, "Tracking Abnormal [%" PRId64 "]", event.common.timestamp);
                    WVR_StopHandTracking();
                    bHandTracking = WVR_StartHandTracking();
                } else {
                    LOGE("ERROR: Receiver HandTracking_Abnormal [%" PRId64 "]", event.common.timestamp);
                    snprintf(mTxtTracking, 63, "ERROR: Receiver HandTracking_Abnormal [%" PRId64 "]", event.common.timestamp);
                }
                break;

            case WVR_EventType_HandGesture_Abnormal:
                if (bHandGesture) {
                    LOGI("Gesture Abnormal [%" PRId64 "]", event.common.timestamp);
                    snprintf(mTxtEvent, 63, "Gesture Abnormal [%" PRId64 "]", event.common.timestamp);
                    WVR_StopHandGesture();
                    bHandGesture = WVR_StartHandGesture();
                } else {
                    LOGE("ERROR: Receiver HandGesture_Abnormal [%" PRId64 "]", event.common.timestamp);
                    snprintf(mTxtTracking, 63, "ERROR: Receiver HandGesture_Abnormal [%" PRId64 "]", event.common.timestamp);
                }
                break;

            case WVR_EventType_HandGesture_Changed:
                snprintf(mTxtEvent, 63, "GestureChanged timestamp = %" PRId64 "", event.common.timestamp);
                LOGI("GestureChanged timestamp = %" PRId64 "", event.common.timestamp);
                if (bHandGesture) {
                    WVR_HandGestureData data;
                    if (WVR_GetHandGestureData(&data) == WVR_Success) {
                        LOGI("WVR_GetHandGesture (right, left, ns) = (%s, %s, %" PRId64 ")",
                            GetGestureTypeName(data.right), GetGestureTypeName(data.left),
                            data.timestamp);
                        snprintf(mTxtGesture, 63, "Gesture(right, left) = (%s, %s)",
                            GetGestureTypeName(data.right), GetGestureTypeName(data.left));
                    } else {
                        LOGI("WVR_GetHandGesture failed.");
                        snprintf(mTxtGesture, 63, "WVR_GetHandGesture failed.");
                        bHandGesture = (WVR_StartHandGesture() == WVR_Success);
                    }
                } else {
                    LOGE("ERROR: event incorrect");
                    snprintf(mTxtEvent, 63, "ERROR: GestureChanged timestamp = %" PRId64 "", event.common.timestamp);
                }
                break;
            }
    }
    if (bHandTracking) {
        WVR_HandSkeletonData data;
        WVR_HandPoseData pose;
        memset(&data, 0, sizeof(WVR_HandSkeletonData));
        memset(&pose, 0, sizeof(WVR_HandPoseData));
        if (WVR_GetHandTrackingData(&data, &pose) == WVR_Success) {
            if (data.right.wrist.timestamp != 0)
                snprintf(mTxtTracking, 63, "timestamp = %" PRId64 "", data.right.wrist.timestamp);
            else if (data.left.wrist.timestamp != 0)
                snprintf(mTxtTracking, 63, "timestamp = %" PRId64 "", data.left.wrist.timestamp);
            else
                snprintf(mTxtTracking, 63, "timestamp = 0");
            LOGI("HandTrackingData %s", mTxtTracking);
            if (data.right.wrist.isValidPose) {
                snprintf(mTxtTracking, 63, "%s, has RIGH", mTxtTracking);
                LOGI("RIGHT");
                dump(data.right);
                dump(pose.right);
            }
            if (data.left.wrist.isValidPose) {
                snprintf(mTxtTracking, 63, "%s, has LEFT", mTxtTracking);
                LOGI("LEFT");
                dump(data.left);
                dump(pose.left);
            }
        } else {
            LOGI("WVR_GetHandTrackingData failed.");
            snprintf(mTxtTracking, 63, "WVR_GetHandTrackingData failed.");
            bHandTracking = (WVR_StartHandTracking() == WVR_Success);
        }
    }
    return false;
}

void Sample::renderScene(WVR_Eye nEye) {
    WVR_RenderMask(nEye);

    // If SeeThrough enabled, no need show others.
    // XXX mHMDPose, mLightDir doesn't need to us
    Matrix4 pose;
    Vector4 LightDir;
    if (mScene->isEnabled()) {
        if (nEye == WVR_Eye_Left)
            mScene->draw(WVR_Eye_Left, mProjectionLeft, mEyePosLeft, pose, LightDir);
        else if (nEye == WVR_Eye_Right)
            mScene->draw(WVR_Eye_Right, mProjectionRight, mEyePosRight, pose, LightDir);
    }
    // Text
    if (mText->isEnabled()) {
        //LOGI("drawText(%s)", mTxtEvent);
        mText->addOneLineText(mTxtEvent, true, false, -.9f, 0.6f, -1.0f);
        mText->addOneLineText(mTxtGesture, false, true, 0, 0, 0);
        mText->addOneLineText(mTxtTracking, false, true, 0, 0, 0);
        if (nEye == WVR_Eye_Left)
            mText->draw(mProjectionLeft, mEyePosLeft, pose, LightDir);
        else if (nEye == WVR_Eye_Right)
            mText->draw(mProjectionRight, mEyePosRight, pose, LightDir);
    }
    glUseProgram(0);
    GLenum glerr = glGetError();
    if (glerr != GL_NO_ERROR) {
        LOGW("glGetError(): %d", glerr);
    }
}

static void render_eye(Sample* self, FrameBufferObject* fbo, const WVR_Eye& eye) {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // set background color "black"

    fbo->bindFrameBuffer(false);
    fbo->glViewportFull();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    self->renderScene(eye);
    fbo->unbindFrameBuffer(false);
}

bool Sample::RenderFrame() {
    //LOGENTRY();

    if (WVR_IsDeviceConnected(WVR_DeviceType_HMD) == true)
        mScene->updateTextures();
    else
        LOGW("The HMD is not connected now");

    uint32_t index_left = WVR_GetAvailableTextureIndex(mLeftEyeQ);
    uint32_t index_right = WVR_GetAvailableTextureIndex(mRightEyeQ);
    render_eye(this, mLeftEyeFBO.at(index_left), WVR_Eye_Left);
    render_eye(this, mRightEyeFBO.at(index_right), WVR_Eye_Right);

    updateTime();

    WVR_TextureParams_t leftEyeTexture = WVR_GetTexture(mLeftEyeQ, index_left);
    WVR_SubmitError e = WVR_SubmitFrame(WVR_Eye_Left, &leftEyeTexture);
    if (e != WVR_SubmitError_None) {
        LOGE("left submit error");
        return false;
    }

    WVR_TextureParams_t rightEyeTexture = WVR_GetTexture(mRightEyeQ, index_right);
    e = WVR_SubmitFrame(WVR_Eye_Right, &rightEyeTexture);
    if (e != WVR_SubmitError_None) {
        LOGE("right submit error");
        return false;
    }
    return true;
}

// XXXXXXX
void Sample::updateHMDMatrixPose() {
    WVR_DevicePosePair_t mVRDevicePairs[WVR_DEVICE_COUNT_LEVEL_1];
    WVR_GetSyncPose(WVR_PoseOriginModel_OriginOnHead, mVRDevicePairs, WVR_DEVICE_COUNT_LEVEL_1);
}

void Sample::updateTime() {
    // Process time variable.
    struct timeval now;
    gettimeofday(&now, NULL);

    mClockCount++;
    if (mRtcTime.tv_usec > now.tv_usec)
        mClockCount = 0;
    if (mClockCount >= VR_MAX_CLOCKS)
        mClockCount--;

    uint32_t timeDiff = timeval_subtract(now, mRtcTime);
    mTimeDiff = timeDiff / 1000000.0f;
    mTimeAccumulator2S += timeDiff;
    mRtcTime = now;
    mFrameCount++;
    if (mTimeAccumulator2S > 2000000) {
        mFPS = mFrameCount / (mTimeAccumulator2S / 1000000.0f);
        LOGI("sample FPS %3.0f", mFPS);
        mFrameCount = 0;
        mTimeAccumulator2S = 0;
    }
}
