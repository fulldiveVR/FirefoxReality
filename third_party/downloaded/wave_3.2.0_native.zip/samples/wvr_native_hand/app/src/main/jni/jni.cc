// "WaveVR SDK 
// © 2017 HTC Corporation. All Rights Reserved.
//
// Unless otherwise required by copyright law and practice,
// upon the execution of HTC SDK license agreement,
// HTC grants you access to and use of the WaveVR SDK(s).
// You shall fully comply with all of HTC’s SDK license agreement terms and
// conditions signed by you and all SDK and API requirements,
// specifications, and documentation provided by HTC to You."

#define  LOG_TAG    "HandSample"
#include <memory>
#include <jni.h>
#include <log.h>
#include <Context.h>
#include <unistd.h>
#include <wvr/wvr.h>
#include <wvr/wvr_render.h>
#include <wvr/wvr_hand.h>
#include "Sample.h"

static bool InitVR() {
    LOGI("InitVR WVR_Init");
    WVR_InitError error = WVR_Init(WVR_AppType_VRContent);
    if (error != WVR_InitError_None) {
        LOGE("WVR_Init failed: error=(%d)%s", error, WVR_GetInitErrorString(error));
        return false;
    }

    // Must initialize render runtime before all OpenGL code.
    WVR_RenderInitParams_t param = { WVR_GraphicsApiType_OpenGL,
                                     WVR_RenderConfig_Default };
    WVR_RenderError error2 = WVR_RenderInit(&param);
    if (error2 != WVR_RenderError_None) {
        LOGE("WVR_RenderInit failed: error=%d", error2);
        return false;
    }
    return true;
}

static void ShutdownVR() {
    WVR_Quit();
}

int main(int argc, char *argv[]) {
    LOGENTRY();

    Sample sample;
    LOGI("Hello main, start call initVR()");
    if (!InitVR()) {
        LOGW("Hello main, InitVR fail, start call ShutdownVR()");
        ShutdownVR();
        return -1;
    }

    if (!sample.Init()) {
        LOGE("error in Init");
        sample.Shutdown();
        ShutdownVR();
        return -1;
    }

    while (1) {
        if (sample.HandleEvent())
            break;

        if (!sample.RenderFrame()) {
            LOGE("error in RenderFrame");
            break;
        }
        // need to check
        sample.updateHMDMatrixPose();
    }

    sample.Shutdown();
    ShutdownVR();

    return 0;
}

extern "C" {
    JNIEXPORT void JNICALL Java_com_htc_vr_sample_hand_MainActivity_init(JNIEnv * env, jobject act, jobject am);
};

JNIEXPORT void JNICALL Java_com_htc_vr_sample_hand_MainActivity_init(JNIEnv * env, jobject activityInstance, jobject assetManagerInstance) {
    LOGI("MainActivity_init: call  Context::getInstance()->init");
    Context::getInstance()->init(env, assetManagerInstance);
    LOGI("register WVR main when library loading");
    WVR_RegisterMain(main);
}

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    new Context(vm);
    return JNI_VERSION_1_6;
}

void JNI_OnUnLoad(JavaVM* vm, void* reserved) {
    delete Context::getInstance();
}

