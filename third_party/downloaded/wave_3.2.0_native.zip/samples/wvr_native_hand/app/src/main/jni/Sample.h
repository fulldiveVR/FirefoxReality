#pragma once

#include <vector>

#include "object/FrameBufferObject.h"
#include "scene/Empty.h"
#include "scene/Text.h"
#include "shared/Matrices.h"

class Sample final {
public:
    Sample();
    ~Sample();

    bool Init();
    void Shutdown();
    bool HandleEvent();

    bool RenderFrame();
    void updateTime();

    Empty* mScene;
    Text* mText;
    void* mLeftEyeQ;
    void* mRightEyeQ;

    uint32_t mIndexLeft;
    uint32_t mIndexRight;
    std::vector<FrameBufferObject*> mLeftEyeFBO;
    std::vector<FrameBufferObject*> mRightEyeFBO;

    float mNearClip;
    float mFarClip;

    Matrix4 mEyePosLeft;
    Matrix4 mEyePosRight;

    Matrix4 mProjectionLeft;
    Matrix4 mProjectionRight;

    uint32_t mRenderWidth;
    uint32_t mRenderHeight;

    void renderScene(WVR_Eye nEye);

    // XXX
    void updateHMDMatrixPose();

    float mTimeDiff;
    uint32_t mTimeAccumulator2S;  // add in micro second.
    struct timeval mRtcTime;
    int mFrameCount = 0;
    float mFPS = 0;
    //std::vector<Clock *> mClocks;
    Object * mClockRoot;

    uint32_t mClockCount = 0;
    char mTxtEvent[64] = {0};
    char mTxtGesture[64] = {0};
    char mTxtTracking[64] = {0};

    bool bHandGesture = false;
    bool bHandTracking = false;
};
