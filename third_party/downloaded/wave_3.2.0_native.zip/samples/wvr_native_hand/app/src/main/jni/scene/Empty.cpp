// "WaveVR SDK 
// © 2017 HTC Corporation. All Rights Reserved.
//
// Unless otherwise required by copyright law and practice,
// upon the execution of HTC SDK license agreement,
// HTC grants you access to and use of the WaveVR SDK(s).
// You shall fully comply with all of HTC’s SDK license agreement terms and
// conditions signed by you and all SDK and API requirements,
// specifications, and documentation provided by HTC to You."

#define LOG_TAG "Empty"
#include <Object.h>
#include <Context.h>
#include <Shader.h>
#include <Texture.h>
#include <VertexArrayObject.h>
#include <GLES3/gl31.h>
#include <GLES3/gl3ext.h>
#include <Empty.h>

#include <log.h>

Empty::Empty(int w, int h)
    : Object()
    , mWidth(w)
    , mHeight(h)
    , mframebuffer(nullptr)
    , mTextureID(0) {

    mName = LOG_TAG;
    mSize = (mWidth * mHeight) * 1.5;
    mVAO = new VertexArrayObject(true, false);
    mframebuffer = (uint8_t*) malloc(mSize);
    memset(mframebuffer, 0xff, mWidth * mHeight);
    memset(mframebuffer + (mWidth * mHeight), 125, mSize - (mWidth * mHeight));
    initTextures();
    initShader();
    updateVertices();
}

Empty::~Empty() {
    if (mframebuffer != nullptr) {
        free(mframebuffer);
        mframebuffer = nullptr;
    }
}

void Empty::initShader() {
    loadShaderFromAsset("shader/vertex/tt_vertex.glsl", "shader/fragment/tyuv_fragment.glsl");
    if (mHasError)
        return;

    mMatrixLocation = mShader->getUniformLocation("matrix");
    mYTextureLocation = mShader->getUniformLocation("yTexture");
mUVTextureLocation = mShader->getUniformLocation("uvTexture");
}

void Empty::initTextures() {
    mVAO->bindVAO();
    mVAO->bindArrayBuffer();

    int stride = (2 + 3) * sizeof(float);
    GLuint offset = 0;
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (const void*) offset);

    offset += sizeof(float) * 3;
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, (const void*) offset);

    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}

void Empty::updateVertices() {
    // The Camera calibration is according to HTC M10.
    const float scale = 1.0f;  // Scale for calibrate the distnace to screen
    const float cameraOffset = 0.044f * 2.0f;  // the camera position on phone
    const float x = 1.0f * scale + cameraOffset;
    const float y = ((float)mHeight)/mWidth * scale;
    const float z = 0.0f;

    const float VrtxCoord [] = {
            //AB
            //CD
            -x, -y, z, 0, 0,  // A
            -x, y, z, 0, 1,  // C
            x, y, z, 1, 1,  // D
            -x, -y, z, 0, 0,  // A
            x, y, z, 1, 1,  // D
            x, -y, z, 1, 0   // B
    };
    mVAO->bindVAO();
    mVAO->bindArrayBuffer();
    glBufferData(GL_ARRAY_BUFFER, sizeof(VrtxCoord), VrtxCoord, GL_STREAM_DRAW);
    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}

void Empty::updateRightVertices() {
    // The Camera calibration is according to HTC M10.
    const float scale = 0.8f;  // Scale for calibrate the distnace to screen
    const float cameraOffset = 0.044f * 2.0f;  // the camera position on phone
    const float x = 1.0f * scale + cameraOffset;
    const float y = ((float)mHeight)/(mWidth/2) * scale;
    const float z = 0.0f;
    const float VrtxCoord [] = {
            //AB
            //CD
            // Textcoord need upside down
            -x,  y, z, 0.5, 1,  // A
            -x, -y, z, 0.5, 0,  // C
            x, -y, z, 1, 0,  // D
            -x,  y, z, 0.5, 1,  // A
            x, -y, z, 1, 0,  // D
            x,  y, z, 1, 1   // B
    };

    mVAO->bindVAO();
    mVAO->bindArrayBuffer();
    glBufferData(GL_ARRAY_BUFFER, sizeof(VrtxCoord), VrtxCoord, GL_STREAM_DRAW);
    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}

void Empty::updateLeftVertices() {
    // The Camera calibration is according to HTC M10.
    const float scale = 0.8f;  // Scale for calibrate the distnace to screen
    const float cameraOffset = 0.044f * 2.0f;  // the camera position on phone
    const float x = 1.0f * scale + cameraOffset;
    const float y = ((float)mHeight)/(mWidth/2) * scale;
    const float z = 0.0f;
    const float VrtxCoord [] = {
            //AB
            //CD
            // Textcoord need upside down
            -x,  y, z, 0, 1,  // A
            -x, -y, z, 0, 0,  // C
            x, -y, z, 0.5, 0,  // D
            -x,  y, z, 0, 1,  // A
            x, -y, z, 0.5, 0,  // D
            x,  y, z, 0.5, 1   // B
    };

    mVAO->bindVAO();
    mVAO->bindArrayBuffer();
    glBufferData(GL_ARRAY_BUFFER, sizeof(VrtxCoord), VrtxCoord, GL_STREAM_DRAW);
    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}


void Empty::updateTextures() {
    //LOGI("Empty::WVR_GetCameraFrameBuffer() ret = %s, (mWidth, mHeight)=(%d, %d), mSize(%d)", ret==true?"true":"false", mWidth, mHeight, mSize);

    glBindTexture(GL_TEXTURE_2D, mTextureID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, mWidth, mHeight, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, mframebuffer);
    glBindTexture(GL_TEXTURE_2D, mUVTextureID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE_ALPHA, mWidth/2, mHeight/2, 0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, mframebuffer + mWidth*mHeight);
}

void Empty::draw(WVR_Eye which, const Matrix4& projection, const Matrix4& eye, const Matrix4& view, const Vector4& lightDir) {
    Matrix4 matrix = eye;
    mShader->useProgram();
    glUniformMatrix4fv(mMatrixLocation, 1, false, matrix.get());
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, (uint32_t)mTextureID/* texture id from native */);
    glUniform1i(mYTextureLocation, 0);
    glUniform1i(mUVTextureLocation, 1);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, (uint32_t)mUVTextureID/* texture id from native */);
    updateVertices();
    mVAO->bindVAO();
    glDrawArrays(GL_TRIANGLES, 0, 6);
    mShader->unuseProgram();
    mVAO->unbindVAO();
}

