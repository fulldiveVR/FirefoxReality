// "WaveVR SDK 
// © 2017 HTC Corporation. All Rights Reserved.
//
// Unless otherwise required by copyright law and practice,
// upon the execution of HTC SDK license agreement,
// HTC grants you access to and use of the WaveVR SDK(s).
// You shall fully comply with all of HTC’s SDK license agreement terms and
// conditions signed by you and all SDK and API requirements,
// specifications, and documentation provided by HTC to You."

#include <Object.h>
#include <wvr/wvr_types.h>
#include <wvr/wvr_camera.h>

class Empty : public Object
{
private:
    int mMatrixLocation = 0;
    int mYTextureLocation = 0;
    uint32_t mWidth = 0;
    uint32_t mHeight = 0;
    uint32_t mSize = 0;
    uint8_t *mframebuffer;

    int mUVTextureLocation = 0;
    uint32_t mTextureID = 0;
    uint32_t mUVTextureID = 0;
    //WVR_GLTexture_t mTextureID = WVR_INVALID_GLTEXTURE_ID;

public:
    /**
     * Empty help see the real world through the HeadMountDevice by using the camera of the
     * HMD or the phone
     * @param app The application.
     * @throws Exception Catch for OpenGL fail.
     */
    Empty(int w, int h);
    ~Empty();
private:
    void initShader();
    void initTextures();
    void updateVertices();
// XXX
    void updateRightVertices();
    void updateLeftVertices();

public:
    void updateTextures();
public:
    virtual void draw(WVR_Eye which, const Matrix4& projection, const Matrix4& eye, const Matrix4& view, const Vector4& lightDir);
};
