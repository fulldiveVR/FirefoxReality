package com.htc.vr.sample.component.hand

import android.util.Log

object Logger {
    internal val TAG = "HandSample"
    fun e(message: String, ex: Throwable) {
        val trace = Exception().getStackTrace()[1]
        val tmp = trace.getFileName().split(".".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val tag = if (tmp.size > 1) tmp[1] else trace.getFileName()
        val msg = "[" + tag + "] " + trace.getMethodName() + " " + message
        Log.e(TAG, msg, ex)
    }

    fun e(message: String) {
        val trace = Exception().getStackTrace()[1]
        val tmp = trace.getFileName().split(".".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val tag = if (tmp.size > 1) tmp[1] else trace.getFileName()
        val msg = "[" + tag + "] " + trace.getMethodName() + " " + message
        Log.e(TAG, msg)
    }


    fun w(message: String) {
        val trace = Exception().getStackTrace()[1]
        val tmp = trace.getFileName().split(".".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val tag = if (tmp.size > 1) tmp[1] else trace.getFileName()
        val msg = "[" + tag + "] " + trace.getMethodName() + " " + message

        Log.w(TAG, msg)
    }

    fun i(message: String) {
        val trace = Exception().getStackTrace()[1]
        val tmp = trace.getFileName().split(".".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val tag = if (tmp.size > 1) tmp[1] else trace.getFileName()
        val msg = "[" + tag + "] " + trace.getMethodName() + " " + message
        Log.i(TAG, msg)
    }

    fun d(message: String) {
        val trace = Exception().getStackTrace()[1]
        val tmp = trace.getFileName().split(".".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val tag = if (tmp.size > 1) tmp[1] else trace.getFileName()
        val msg = "[" + tag + "] " + trace.getMethodName() + " " + message
        Log.d(TAG, msg)
    }

    fun v(message: String) {
        val trace = Exception().getStackTrace()[1]
        val tmp = trace.getFileName().split(".".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val tag = if (tmp.size > 1) tmp[1] else trace.getFileName()
        val msg = "[" + tag + "] " + trace.getMethodName() + " " + message
        Log.v(TAG, msg)
    }
}