package com.htc.vr.sample.component.hand

import com.htc.vr.GestureType
import com.htc.vr.HandGestureState
import com.htc.vr.component.AbstractHandGesture
import java.util.Random

import android.os.Handler
import android.os.HandlerThread

class GestureSample() : AbstractHandGesture() {
    private lateinit var mThread: WorkerThread

    override fun onStart(): Boolean {
        Logger.i("+")
        mThread = WorkerThread(this).apply {
            start()
            scheduleStart()
        }
        Logger.i("-")
        return true
    }

    override fun onStop() {
        Logger.i("+")
        mThread.scheduleStop()
        mThread.quitSafely()
        mThread.join()
        Logger.i("-")
    }

    private class WorkerThread(val context: AbstractHandGesture) : HandlerThread("GestureRandomWorker") {
        private val mHandler by lazy { Handler(looper) }
        private var mRunning = false

        fun scheduleStart() {
            mHandler.post {
                mRunning = true
                scheduleUpdate()
            }
        }

        fun scheduleStop() {
            mHandler.post {
                mRunning = false
            }
        }
        var fake = 0
        fun scheduleUpdate() {
            val fn = head@ {
                if (!mRunning)
                    return@head

                val random = Random()
                context. updateData(
                        HandGestureState(
                                convert((fake++) % 7),
                                convert((fake++) % 7))
                )
                scheduleUpdate()
            }
            mHandler.postDelayed(fn, 100)
        }

        fun convert(gesture: Int): GestureType {
            when (gesture) {
                1 -> return GestureType.UNKNOWN
                2 -> return GestureType.FIST
                3 -> return GestureType.FIVE
                4 -> return GestureType.OK
                5 -> return GestureType.THUMB_UP
                6 -> return GestureType.INDEX_UP
                else -> return GestureType.INVALID
            }
        }
    }
}