package com.htc.vr.sample.component.hand;

import com.htc.vr.component.VRComponentApplication

class HandApplication : VRComponentApplication() {

    override fun onCreate() {
        super.onCreate()
        addService(GestureSample())
        addService(TrackerSample())
    }
}
