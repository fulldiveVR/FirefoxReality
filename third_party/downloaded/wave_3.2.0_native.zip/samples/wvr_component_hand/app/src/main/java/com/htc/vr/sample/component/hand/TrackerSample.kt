package com.htc.vr.sample.component.hand

import com.htc.vr.Vector3
import com.htc.vr.Quaternion
import com.htc.vr.Finger
import com.htc.vr.Hand
import com.htc.vr.HandTracking
import com.htc.vr.component.AbstractHandTracker
import java.util.Random

class TrackerSample() : AbstractHandTracker() {
    private lateinit var mThread: Thread
    private var mQuit = false

    override fun onStart(): Boolean {
        Logger.i("+")
        mQuit = false
        mThread = Thread(mRunnable)
        mThread.start()
        Logger.i("-")
        return true
    }

    override fun onStop() {
        Logger.i("+")
        mQuit = true
        try {
            mThread.join(1000)
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
        Logger.i("-")
    }

    internal var mRunnable: Runnable = Runnable {
        while (!mQuit) {
            updateData(getData())
            try {
                Thread.sleep(1000)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }

        }
    }

    internal fun createVec3f(value: Float): Vector3 {
        return Vector3(value, value, value)
    }

    internal fun createQuaternion(value: Float): Quaternion {
        return Quaternion(
                value,
                value.plus(0.0001f),
                value.plus(0.0002f),
                value.plus(0.0003f))
    }

    internal fun createFinger(value: Float): Finger {
        return Finger(
                createVec3f(value),
                createVec3f(value.plus(0.0002f)),
                createVec3f(value.plus(0.0004f)),
                createVec3f(value.plus(0.0006f)))
    }

    internal fun getData(): HandTracking {
        val random = Random()
        val p = random.nextInt(10).toFloat()
        //Random random = new Random();
        val left = Hand(
                createVec3f(0.0001f + p),
                createQuaternion(0.0001f + p),
                createVec3f(0.0001f + p),
                createVec3f(0.0001f + p),
                createFinger(0.001f + p),
                createFinger(0.002f + p),
                createFinger(0.003f + p),
                createFinger(0.004f + p),
                createFinger(0.005f + p)
        )

        val right = Hand(
                createVec3f(0.0005f + p),
                createQuaternion(0.0005f + p),
                createVec3f(0.0005f + p),
                createVec3f(0.0005f + p),
                createFinger(0.006f + p),
                createFinger(0.007f + p),
                createFinger(0.008f + p),
                createFinger(0.009f + p),
                createFinger(0.01f + p)
        )
        return HandTracking(right, left)
    }
}