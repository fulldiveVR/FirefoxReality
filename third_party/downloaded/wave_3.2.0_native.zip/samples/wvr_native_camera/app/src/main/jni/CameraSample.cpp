#include <wvr/wvr_types.h>
#include <wvr/wvr_events.h>
#include <wvr/wvr_device.h>
#include <wvr/wvr_render.h>
#include <wvr/wvr_projection.h>

#include <EGL/egl.h>
#include <GLES3/gl31.h>

#include <atomic>
#include <jni.h>

#include "CameraSample.h"
#include "log.h"

#define VR_MAX_CLOCKS 200
// Return micro second.  Should always positive because now is bigger.
#define timeval_subtract(now, last) \
    ((now.tv_sec - last.tv_sec) * 1000000LL + now.tv_usec - last.tv_usec)

// -----------------------------------------------------------
static void printGLString(const char *name, GLenum s) {
    const char *v = (const char *) glGetString(s);
    LOGI("GL %s = %s\n", name, v);
}

static void dumpMatrix(const char * name, const Matrix4& mat) {
    const float * ptr = mat.get();
    LOGD("%s =\n"
                 " ⎡%+6f  %+6f  %+6f  %+6f⎤\n"
                 " ⎢%+6f  %+6f  %+6f  %+6f⎥\n"
                 " ⎢%+6f  %+6f  %+6f  %+6f⎥\n"
                 " ⎣%+6f  %+6f  %+6f  %+6f⎦\n",
         name,
         ptr[0], ptr[4], ptr[8],  ptr[12],
         ptr[1], ptr[5], ptr[9],  ptr[13],
         ptr[2], ptr[6], ptr[10], ptr[14],
         ptr[3], ptr[7], ptr[11], ptr[15]);
}
// -----------------------------------------------------------

CameraSample::CameraSample()
        : mSeeThrough(NULL)
        , mLeftEyeQ(NULL)
        , mRightEyeQ(NULL) {

}

CameraSample::~CameraSample() {}

bool CameraSample::Init() {
    LOGI("Init");
    ///initGL();
    mSeeThrough = new SeeThrough();
    mSeeThrough->setEnable(true);

    uint32_t width, height;
    WVR_GetRenderTargetSize(&width, &height);
    LOGI("WVR_GetRenderTargetSize: width=%d, height=%d", width, height);


    mLeftEyeQ = WVR_ObtainTextureQueue(WVR_TextureTarget_2D,
                                       WVR_TextureFormat_RGBA,
                                       WVR_TextureType_UnsignedByte,
                                       width, height, 0);

    LOGI("mLeftEyeQ size: %d", WVR_GetTextureQueueLength(mLeftEyeQ));
    for (int i = 0; i < WVR_GetTextureQueueLength(mLeftEyeQ); i++) {
        FrameBufferObject* fbo;

        fbo = new FrameBufferObject((int)WVR_GetTexture(mLeftEyeQ, i).id, width, height);
        if (fbo->hasError()) {
            LOGI("fbo for mLeftEyeQ has error");
            return false;
        }
        mLeftEyeFBO.push_back(fbo);
    }

    mRightEyeQ = WVR_ObtainTextureQueue(WVR_TextureTarget_2D,
                                        WVR_TextureFormat_RGBA,
                                        WVR_TextureType_UnsignedByte,
                                        width, height, 0);

    LOGI("mRightEyeQ size: %d", WVR_GetTextureQueueLength(mRightEyeQ));
    for (int i = 0; i < WVR_GetTextureQueueLength(mRightEyeQ); i++) {
        FrameBufferObject* fbo;

        fbo = new FrameBufferObject((int)WVR_GetTexture(mRightEyeQ, i).id, width, height);
        if (fbo->hasError()) {
            LOGI("fbo for mRightEyeQ has error");
            return false;
        }
        mRightEyeFBO.push_back(fbo);
    }

    return true;
}

void CameraSample::Shutdown() {
    LOGI("Shutdown");
    if (mSeeThrough != NULL) {
        mSeeThrough->setEnable(false);
        delete mSeeThrough;
    }
    mSeeThrough = NULL;

    if (mLeftEyeQ != 0) {
        for (int i = 0; i < WVR_GetTextureQueueLength(mLeftEyeQ); i++) {
            delete mLeftEyeFBO.at(i);
        }
        WVR_ReleaseTextureQueue(mLeftEyeQ);
    }

    if (mRightEyeQ != 0) {
        for (int i = 0; i < WVR_GetTextureQueueLength(mRightEyeQ); i++) {
            delete mRightEyeFBO.at(i);
        }
        WVR_ReleaseTextureQueue(mRightEyeQ);
    }
}

std::atomic<bool> sResume {false};

bool CameraSample::HandleEvent() {
    // Process WVR events
    WVR_Event_t event;
    while(WVR_PollEventQueue(&event)) {
        //LOGI("HandleEvent (%d)", event.common.type);
        if (event.common.type == WVR_EventType_Quit) {
            return true;
        }
        // TODO - VR Events
    }
    if (sResume) {
        sResume = false;
        if (mSeeThrough) {
            mSeeThrough->resumeCamera();
        }
    }
    return false;
}

extern "C" {
JNIEXPORT void JNICALL
Java_com_htc_vr_samples_vrcamera_MainActivity_nativeOnResume(
    JNIEnv* env, jobject thiz) {
        //LOGI("jni sResume(%d)", sResume);
        if (sResume) {
            LOGI("jni sResume = true");
        } else {
            LOGI("jni sResume = false");
        }
	sResume = true;
}
}

void CameraSample::renderScene(WVR_Eye nEye) {
    WVR_RenderMask(nEye);

    // If SeeThrough enabled, no need show others.
    // XXX mHMDPose, mLightDir doesn't need to us
    Matrix4 HMDPose;
    Vector4 LightDir;
    if (mSeeThrough->isEnabled()) {
        if (nEye == WVR_Eye_Left)
            mSeeThrough->draw(WVR_Eye_Left, mProjectionLeft, mEyePosLeft, HMDPose, LightDir);
        else if (nEye == WVR_Eye_Right)
            mSeeThrough->draw(WVR_Eye_Right, mProjectionRight, mEyePosRight, HMDPose, LightDir);
        return;
    }
    glUseProgram(0);
    GLenum glerr = glGetError();
    if (glerr != GL_NO_ERROR) {
        LOGW("glGetError(): %d", glerr);
    }
}


static void render_left_eye(CameraSample* self, FrameBufferObject* fbo) {
    LOGENTRY();
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // set background color "black"

    fbo->bindFrameBuffer(false);
    fbo->glViewportFull();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    self->renderScene(WVR_Eye_Left);
    fbo->unbindFrameBuffer(false);
}

static void render_right_eye(CameraSample* self, FrameBufferObject* fbo) {
    LOGENTRY();
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // set background color "black"

    fbo->bindFrameBuffer(false);
    fbo->glViewportFull();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    self->renderScene(WVR_Eye_Right);
    fbo->unbindFrameBuffer(false);
}

bool CameraSample::RenderFrame() {
    LOGENTRY();

    if (WVR_IsDeviceConnected(WVR_DeviceType_HMD) == true)
        mSeeThrough->updateTextures();
    else
        LOGW("The HMD is not connected now");

    uint32_t index_left = WVR_GetAvailableTextureIndex(mLeftEyeQ);
    uint32_t index_right = WVR_GetAvailableTextureIndex(mRightEyeQ);
    render_left_eye(this, mLeftEyeFBO.at(index_left));
    render_right_eye(this, mRightEyeFBO.at(index_right));

    updateTime();

    WVR_TextureParams_t leftEyeTexture = WVR_GetTexture(mLeftEyeQ, index_left);
    // Try to get smooth see-through camera
    WVR_PoseState_t pose = mSeeThrough->getImmediatePose();
    WVR_SubmitError e = WVR_SubmitFrame(WVR_Eye_Left, &leftEyeTexture, &pose);
    if (e != WVR_SubmitError_None) {
        LOGE("left submit error");
        return false;
    }

    WVR_TextureParams_t rightEyeTexture = WVR_GetTexture(mRightEyeQ, index_right);
    e = WVR_SubmitFrame(WVR_Eye_Right, &rightEyeTexture);
    if (e != WVR_SubmitError_None) {
        LOGE("right submit error");
        return false;
    }

    return true;
}

// XXXXXXX
void CameraSample::updateHMDMatrixPose() {
    LOGI("updateHMDMatrixPose");
    WVR_DevicePosePair_t mVRDevicePairs[WVR_DEVICE_COUNT_LEVEL_1];
    WVR_GetSyncPose(WVR_PoseOriginModel_OriginOnHead, mVRDevicePairs, WVR_DEVICE_COUNT_LEVEL_1);
}

void CameraSample::updateTime() {
    // Process time variable.
    struct timeval now;
    gettimeofday(&now, NULL);

    mClockCount++;
    if (mRtcTime.tv_usec > now.tv_usec)
        mClockCount = 0;
    if (mClockCount >= VR_MAX_CLOCKS)
        mClockCount--;

    uint32_t timeDiff = timeval_subtract(now, mRtcTime);
    mTimeDiff = timeDiff / 1000000.0f;
    mTimeAccumulator2S += timeDiff;
    mRtcTime = now;
    mFrameCount++;
    if (mTimeAccumulator2S > 2000000) {
        mFPS = mFrameCount / (mTimeAccumulator2S / 1000000.0f);
        LOGI("VRCamera FPS %3.0f", mFPS);

        mFrameCount = 0;
        mTimeAccumulator2S = 0;
    }

   // mClocks[mClockCount]->getTransform().identity().rotateZ(-mRtcTime.tv_usec / 1000000.0f * 360.0f);
}
