// "WaveVR SDK 
// © 2017 HTC Corporation. All Rights Reserved.
//
// Unless otherwise required by copyright law and practice,
// upon the execution of HTC SDK license agreement,
// HTC grants you access to and use of the WaveVR SDK(s).
// You shall fully comply with all of HTC’s SDK license agreement terms and
// conditions signed by you and all SDK and API requirements,
// specifications, and documentation provided by HTC to You."

package com.htc.vr.samples.vrcamera;

import com.htc.vr.BuildConfig;
import com.htc.vr.sdk.VRActivity;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.annotation.TargetApi;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;


public class MainActivity extends VRActivity {
    private static final String TAG = "VRCamera";

    static {
        System.loadLibrary("sample_vrcamera");
    }
    public MainActivity() {
        super.setUsingRenderBaseActivity(true);
    }

    @Override
    protected void onCreate(Bundle icicle) {
        Log.i(TAG,"onCreate:call init");
        init(getResources().getAssets());
        super.onCreate(icicle);

        // dump verion information
        try {
            Log.i(TAG, "(Native HelloVR) VR_VERSION: " + BuildConfig.VR_VERSION);
            PackageManager pm = getPackageManager();
            PackageInfo info = pm.getPackageInfo(getApplicationInfo().packageName, 0);
            Log.i(TAG, "Native HelloVR version name: " + info.versionName + " code: " + info.versionCode);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        Log.i(TAG,"onCreate:call requestCameraPermission");
        requestCameraPermission();
        Log.i(TAG,"onCreate:call requestCameraPermission end");
        Log.i(TAG,"onCreate:end");

        if(icicle!= null) {
            String operation = icicle.getString("operation");
            if (operation != null && !operation.isEmpty() && operation.equals("close")) {
                Handler handle = new Handler();
                handle.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Log.d(TAG, "run: Close Camera Activity");
                        MainActivity.this.finishAndRemoveTask();
                    }
                }, 100);
            }
        }
    }

    // The camera support.
    // If the external camera exist, we use external camera.
    // If not, we use the camera on the phone.  However the phone's camera
    // need the permission to get work.  Please add a right permission in the
    // AndroidManifest.
    private boolean mHasCameraPermission = false;
    // handle onResume StartCamera
    private native void nativeOnResume();

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"onResume:start");
        nativeOnResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG,"onPause:start");
    }

    @TargetApi(23)
    private void requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, 1);
            }else{
                mHasCameraPermission = true;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,  String[] permissions,  int[] grantResults) {
        // Avoid crash when user don't confirm the permission after pause/resume.
        if (requestCode == 1 && grantResults != null && grantResults.length > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mHasCameraPermission = true;
            }
        }
    }

    // Pass this acitivty instance to native
    @SuppressWarnings("unused")
    public native void init(AssetManager am);
}
