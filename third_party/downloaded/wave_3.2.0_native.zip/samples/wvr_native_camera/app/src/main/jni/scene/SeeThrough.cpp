// "WaveVR SDK
// © 2017 HTC Corporation. All Rights Reserved.
//
// Unless otherwise required by copyright law and practice,
// upon the execution of HTC SDK license agreement,
// HTC grants you access to and use of the WaveVR SDK(s).
// You shall fully comply with all of HTC’s SDK license agreement terms and
// conditions signed by you and all SDK and API requirements,
// specifications, and documentation provided by HTC to You."

#define LOG_TAG "SeeThrough"
#include <Object.h>
#include <Context.h>
#include <Shader.h>
#include <Texture.h>
#include <VertexArrayObject.h>
#include <GLES3/gl31.h>
#include <GLES3/gl3ext.h>
#include <SeeThrough.h>

#include <log.h>

SeeThrough::SeeThrough()
    : Object()
    , mframebuffer(nullptr)
    , mTextureID(0) {

    mName = LOG_TAG;
    mEnable = false;
    mVAO = new VertexArrayObject(true, false);
}

SeeThrough::~SeeThrough() {
/*
    if (mframebuffer != nullptr) {
        free(mframebuffer);
        mframebuffer = nullptr;
    }*/
}

void SeeThrough::initShader() {
    if (mImgFormat == WVR_CameraImageFormat_YUV_420) {
        loadShaderFromAsset("shader/vertex/tt_vertex.glsl", "shader/fragment/tyuv_fragment.glsl");
        if (mHasError)
            return;

        mMatrixLocation = mShader->getUniformLocation("matrix");
        mYTextureLocation = mShader->getUniformLocation("yTexture");
        mUVTextureLocation = mShader->getUniformLocation("uvTexture");
    } else {
        loadShaderFromAsset("shader/vertex/tt_vertex.glsl", "shader/fragment/tt_fragment.glsl");
        if (mHasError)
            return;

        mMatrixLocation = mShader->getUniformLocation("matrix");
        mYTextureLocation = mShader->getUniformLocation("yTexture");
    }
}

void SeeThrough::initTextures() {
    mVAO->bindVAO();
    mVAO->bindArrayBuffer();

    int stride = (2 + 3) * sizeof(float);
    GLuint offset = 0;
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, false, stride, (const void*) offset);

    offset += sizeof(float) * 3;
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, (const void*) offset);

    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}

void SeeThrough::updateVertices() {
    // The Camera calibration is according to HTC M10.
    const float scale = 0.8f;  // Scale for calibrate the distnace to screen
    const float cameraOffset = 0.044f * 2.0f;  // the camera position on phone
    const float x = 1.0f * scale + cameraOffset;
    const float y = ((float)mHeight)/mWidth * scale;
    const float z = 0.0f;

    const float VrtxCoord [] = {
            //AB
            //CD
            -x, -y, z, 0, 0,  // A
            -x, y, z, 0, 1,  // C
            x, y, z, 1, 1,  // D
            -x, -y, z, 0, 0,  // A
            x, y, z, 1, 1,  // D
            x, -y, z, 1, 0   // B
    };
    mVAO->bindVAO();
    mVAO->bindArrayBuffer();
    glBufferData(GL_ARRAY_BUFFER, sizeof(VrtxCoord), VrtxCoord, GL_STREAM_DRAW);
    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}

void SeeThrough::updateRightVertices() {
    // The Camera calibration is according to HTC M10.
    const float scale = 0.8f;  // Scale for calibrate the distnace to screen
    const float cameraOffset = 0.044f * 2.0f;  // the camera position on phone
    const float x = 1.0f * scale + cameraOffset;
    const float y = ((float)mHeight)/(mWidth/2) * scale;
    const float z = 0.0f;
    const float VrtxCoord [] = {
            //AB
            //CD
            // Textcoord need upside down
            -x,  y, z, 0.5, 1,  // A
            -x, -y, z, 0.5, 0,  // C
            x, -y, z, 1, 0,  // D
            -x,  y, z, 0.5, 1,  // A
            x, -y, z, 1, 0,  // D
            x,  y, z, 1, 1   // B
    };

    mVAO->bindVAO();
    mVAO->bindArrayBuffer();
    glBufferData(GL_ARRAY_BUFFER, sizeof(VrtxCoord), VrtxCoord, GL_STREAM_DRAW);
    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}

void SeeThrough::updateLeftVertices() {
    // The Camera calibration is according to HTC M10.
    const float scale = 0.8f;  // Scale for calibrate the distnace to screen
    const float cameraOffset = 0.044f * 2.0f;  // the camera position on phone
    const float x = 1.0f * scale + cameraOffset;
    const float y = ((float)mHeight)/(mWidth/2) * scale;
    const float z = 0.0f;
    const float VrtxCoord [] = {
            //AB
            //CD
            // Textcoord need upside down
            -x,  y, z, 0, 1,  // A
            -x, -y, z, 0, 0,  // C
            x, -y, z, 0.5, 0,  // D
            -x,  y, z, 0, 1,  // A
            x, -y, z, 0.5, 0,  // D
            x,  y, z, 0.5, 1   // B
    };

    mVAO->bindVAO();
    mVAO->bindArrayBuffer();
    glBufferData(GL_ARRAY_BUFFER, sizeof(VrtxCoord), VrtxCoord, GL_STREAM_DRAW);
    mVAO->unbindVAO();
    mVAO->unbindArrayBuffer();
}

WVR_PoseState_t SeeThrough::getImmediatePose() {
    return mPose;
}

void SeeThrough::updateTextures() {
    if (!mEnable)
        return;

    bool ret = WVR_GetCameraFrameBuffer(mframebuffer, mSize);
    if (ret == false) {
        LOGI("%s(%d) WVR_GetCameraFrameBuffer return error", __FUNCTION__, __LINE__);
        return;
    }
    // Try to get smooth see-through camera
    WVR_GetPoseState(WVR_DeviceType_HMD, WVR_PoseOriginModel_OriginOnGround, 0, &mPose);
    if (mPose.isValidPose) {
        LOGI("%s(%d) smooth camera get pose timestamp(%lld)", __FUNCTION__, __LINE__, mPose.timestamp);
    } else {
        LOGI("%s(%d) smooth camera get invalid pose", __FUNCTION__, __LINE__);
    }

    //LOGI("SeeThrough::WVR_GetCameraFrameBuffer() ret = %s, (mWidth, mHeight)=(%d, %d), mSize(%d)", ret==true?"true":"false", mWidth, mHeight, mSize);

    glBindTexture(GL_TEXTURE_2D, mTextureID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0);
    if (mImgFormat == WVR_CameraImageFormat_YUV_420) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, mWidth, mHeight, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, mframebuffer);
        glBindTexture(GL_TEXTURE_2D, mUVTextureID);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE_ALPHA, mWidth/2, mHeight/2, 0, GL_LUMINANCE_ALPHA, GL_UNSIGNED_BYTE, mframebuffer + mWidth*mHeight);
    } else if (mImgFormat == WVR_CameraImageFormat_Grayscale) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, mWidth, mHeight, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, mframebuffer);
    }
}

bool SeeThrough::requestCamera(bool enable) {
    LOGI("SeeThrough::requestCamera enable(%s)", enable==true? "true" : "false");
    if (enable) {
        WVR_CameraInfo cameraInfo;
        bool ret = false;
        ret = WVR_StartCamera(&cameraInfo);
        if (ret == false) {
            LOGE("SeeThrough::requestCamera WVR_StartCamera return false");
            return false;
        }

        mSize = cameraInfo.size;
        mWidth = cameraInfo.width;
        mHeight = cameraInfo.height;
        mframebuffer = (uint8_t *)malloc(mSize);
        mImgType = cameraInfo.imgType;
        mImgFormat = cameraInfo.imgFormat;
        //glActiveTexture(mTextureID);
        glGenTextures(1, &mTextureID);
        glBindTexture(GL_TEXTURE_2D, mTextureID);
        GLint err = glGetError();
        if (err != GL_NO_ERROR) {
            LOGE("GL error after %s: 0x%08x\n", __FUNCTION__, err);
        }
        if (cameraInfo.imgFormat == WVR_CameraImageFormat_YUV_420) {
            glGenTextures(1, &mUVTextureID);
        }

        LOGI("SeeThrough requestCamera imgType(%d), width = %d, height = %d, mSize = %d", cameraInfo.imgType, mWidth, mHeight, mSize);

        // request camera parameters
        WVR_CameraIntrinsic cameraIntrinsic;
        ret = WVR_GetCameraIntrinsic(WVR_CameraPosition_Left, &cameraIntrinsic);
        if (ret == true) {
            LOGI("CameraParameters CameraIntrinsic focalLength(x, y) = (%f, %f)",
                  cameraIntrinsic.focalLength.v[0], cameraIntrinsic.focalLength.v[1]);
            LOGI("CameraParameters CameraIntrinsic principalPoint(x, y) = (%f, %f)",
                 cameraIntrinsic.principalPoint.v[0], cameraIntrinsic.principalPoint.v[1]);
        } else {
            LOGW("Your HMD can't get camera intrinsic parameters");
        }

        ret = WVR_GetCameraIntrinsic(WVR_CameraPosition_Right, &cameraIntrinsic);
        if (ret == true) {
            LOGI("CameraParameters CameraIntrinsic focalLength(x, y) = (%f, %f)",
                 cameraIntrinsic.focalLength.v[0], cameraIntrinsic.focalLength.v[1]);
            LOGI("CameraParameters CameraIntrinsic principalPoint(x, y) = (%f, %f)",
                 cameraIntrinsic.principalPoint.v[0], cameraIntrinsic.principalPoint.v[1]);
        } else {
            LOGW("Your HMD can't get camera intrinsic parameters");
        }

    } else {
        WVR_StopCamera();

        mWidth = 0;
        mHeight = 0;
        mTextureID = 0;
        if (mframebuffer != nullptr) {
            free(mframebuffer);
            mframebuffer = nullptr;
        }
    }
    return true;
}

void SeeThrough::resumeCamera() {
    LOGI("SeeThrough::ResumeCamera enter");
    WVR_CameraInfo cameraInfo;
    bool ret = false;
    ret = WVR_StartCamera(&cameraInfo);
    if (ret == false) {
        LOGE("SeeThrough::ResumeCamera fail");
        return;
    }

    mSize = cameraInfo.size;
    mWidth = cameraInfo.width;
    mHeight = cameraInfo.height;
    mframebuffer = (uint8_t *)malloc(mSize);
    mImgType = cameraInfo.imgType;
    mImgFormat = cameraInfo.imgFormat;
}

void SeeThrough::setEnable(bool enable) {
    if (mEnable == enable)
        return;
    if (enable) {
        if (!requestCamera(true))
            return;
        initTextures();
        initShader();
        updateVertices();
    } else {
        requestCamera(false);
    }
    mEnable = enable;
}

void SeeThrough::draw(WVR_Eye which, const Matrix4& projection, const Matrix4& eye, const Matrix4& view, const Vector4& lightDir) {
    if (!mEnable)
        return;

    Matrix4 matrix = eye;

    mShader->useProgram();
    glUniformMatrix4fv(mMatrixLocation, 1, false, matrix.get());

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, (uint32_t)mTextureID/* texture id from native */);
    glUniform1i(mYTextureLocation, 0);

    if (mImgFormat == WVR_CameraImageFormat_YUV_420) {
        glUniform1i(mUVTextureLocation, 1);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, (uint32_t)mUVTextureID/* texture id from native */);
    }

    // Android Camera
    if (mImgType == WVR_CameraImageType_SingleEye) {
        updateVertices();
    } else if (mImgType == WVR_CameraImageType_DualEye) {
        if (which == WVR_Eye_Left)
            updateLeftVertices();
        else if (which == WVR_Eye_Right)
            updateRightVertices();
        else
            LOGE("Do nothing");
    } else {
        LOGE("Unknown Image Format(%d)", mImgFormat);
    }

    mVAO->bindVAO();
    glDrawArrays(GL_TRIANGLES, 0, 6);
    mShader->unuseProgram();
    mVAO->unbindVAO();
}

