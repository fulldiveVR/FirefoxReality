#pragma once

#include <vector>

#include "object/FrameBufferObject.h"
#include "scene/SeeThrough.h"
#include "shared/Matrices.h"

class CameraSample final {
public:
    CameraSample();

    ~CameraSample();

    bool Init();

    void Shutdown();

    bool HandleEvent();

    bool RenderFrame();
    void updateTime();

    inline Matrix4 wvrmatrixConverter(const WVR_Matrix4f_t& mat) const {
        return Matrix4(
                mat.m[0][0], mat.m[1][0], mat.m[2][0], mat.m[3][0],
                mat.m[0][1], mat.m[1][1], mat.m[2][1], mat.m[3][1],
                mat.m[0][2], mat.m[1][2], mat.m[2][2], mat.m[3][2],
                mat.m[0][3], mat.m[1][3], mat.m[2][3], mat.m[3][3]
        );
    }

    SeeThrough * mSeeThrough;
    void* mLeftEyeQ;
    void* mRightEyeQ;

    uint32_t mIndexLeft;
    uint32_t mIndexRight;
    std::vector<FrameBufferObject*> mLeftEyeFBO;
    std::vector<FrameBufferObject*> mRightEyeFBO;

    float mNearClip;
    float mFarClip;

    Matrix4 mEyePosLeft;
    Matrix4 mEyePosRight;

    Matrix4 mProjectionLeft;
    Matrix4 mProjectionRight;

    uint32_t mRenderWidth;
    uint32_t mRenderHeight;

    void renderScene(WVR_Eye nEye);

    // XXX
    void updateHMDMatrixPose();

    float mTimeDiff;
    uint32_t mTimeAccumulator2S;  // add in micro second.
    struct timeval mRtcTime;
    int mFrameCount = 0;
    float mFPS = 0;
    //std::vector<Clock *> mClocks;
    Object * mClockRoot;


    uint32_t mClockCount = 0;

};
