package htc.com.vr.sample.simpledevice;

import com.htc.vr.sdk.pluginkit.VRDevice;
import com.htc.vr.sdk.pluginkit.VRDeviceService;

import java.util.Vector;

public class SimpleService extends VRDeviceService {

    @Override
    public void onCreate() {
        super.onCreate();
        Vector<VRDevice> devices = new Vector<>();
        devices.add(new MyHmdDevice());
        devices.add(new MyControllerDevice());
        devices.add(new MyTrackerDevice());
        for (VRDevice device : devices) {
            registerDevice(device);
            device.connect();
        }
    }
}
