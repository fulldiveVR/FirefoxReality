package htc.com.vr.sample.simpledevice;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;

class Utils {
    static final String TAG = "VRCORE SimpleDev";

    public static void Log(String log) {
        Log.d(TAG, _FILE_() + ":" + _FUNC_() + "(" + _LINE_() + ") " + log);
    }

    // 当前文件名
    private static String _FILE_() {
        StackTraceElement traceElement = ((new Exception()).getStackTrace())[2];
        return traceElement.getFileName();
    }

    // 当前方法名
    private static String _FUNC_() {
        StackTraceElement traceElement = ((new Exception()).getStackTrace())[2];
        return traceElement.getMethodName();
    }

    // 当前行号
    private static int _LINE_() {
        StackTraceElement traceElement = ((new Exception()).getStackTrace())[2];
        return traceElement.getLineNumber();
    }

    // 当前时间
    private static String _TIME_() {
        Date now = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return sdf.format(now);
    }
}
