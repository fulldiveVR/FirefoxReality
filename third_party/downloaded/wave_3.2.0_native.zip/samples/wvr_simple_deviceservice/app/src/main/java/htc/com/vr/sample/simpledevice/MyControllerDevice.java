package htc.com.vr.sample.simpledevice;

import com.htc.vr.sdk.Pose;
import com.htc.vr.sdk.Quaternion;
import com.htc.vr.sdk.Vector;
import com.htc.vr.sdk.pluginkit.ControllerDevice;
import com.htc.vr.sdk.WVR;
import com.htc.vr.sdk.pluginkit.AttributeError;
import java.util.HashMap;
import android.util.Log;

class MyControllerDevice extends ControllerDevice {
    protected boolean mIsConnected;
    private final String TAG = "MyControllerDevice";
    final Pose mPose = new Pose();
    Thread mThread = null;

    public MyControllerDevice() {
        super();
        connect();
        mPose.translation = new Vector();
        mPose.rotation = new Quaternion();
        mPose.rotation.w = 1;
    }

    @Override
    public void onResume() {
        Utils.Log(TAG + "onResume");
    }

    @Override
    public void onStart() {
        Utils.Log("");
        //mSensorManager.registerListener(this, mAccelerometer, mMinSensorDelay);
        mIsConnected = true;
        mThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (mIsConnected) {
                    //mPose.rotation.x += 0.001;
                    if (mPose.rotation.x > 3)
                        mPose.rotation.x = -3;
                    //mPose.rotation.y += 0.001;
                    if (mPose.rotation.y > 3)
                        mPose.rotation.y = -3;
                    mPose.rotation.z += 0.001;
                    if (mPose.rotation.z > 3)
                        mPose.rotation.z = 0;

                    updatePose(mPose, System.nanoTime());
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        mThread.start();
    }

    @Override
    public void onPause() {
        Utils.Log(TAG + "onPause");
    }

    @Override
    public void onStop() {
        Utils.Log("");
        mIsConnected=false;
        try {
            mThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Config setupConfig() {
        Config configure = new Config();
        configure.trackingSystemName = "Controller Device";
        configure.modelNumber = "";
        configure.manufacturerName = "HTC";
        configure.hardwareRevision = "11111";
        configure.deviceProvidesBatteryStatus = true;
        configure.containsRecenter = false;
        configure.contains6Dof = false;
        configure.trackingModelType = 0;
        configure.supportVirDpadSwipeInputId = WVR.InputId_Alias1_Touchpad;
        configure.disableVirtualDpad = false;

        int support = 0;
        support |= ButtonMaskFromId(WVR.InputId_Alias1_System);
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Menu);
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Grip);
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Touchpad);
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Trigger);
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Thumbstick);


        configure.supportedButton = support;
        support = 0;
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Touchpad);
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Trigger);
        support |= ButtonMaskFromId(WVR.InputId_Alias1_Thumbstick);
        configure.supportedAnalog = support;
        configure.supportedTouch = support;

        configure.analogType = new HashMap<Integer, Integer>();
        configure.analogType.put(WVR.InputId_Alias1_Trigger, WVR.AnalogType_1D);
        configure.analogType.put(WVR.InputId_Alias1_Touchpad, WVR.AnalogType_2D);
        configure.analogType.put(WVR.InputId_Alias1_Thumbstick, WVR.AnalogType_2D);
        return configure;
    }

    public long ButtonMaskFromId( int id ) { return 1<< id; }

    @Override
    public void onTrackingModeChanged(int mode) {
        switch (mode) {
            case WVR.TrackingMode.VR3DoF:
                break;
            case WVR.TrackingMode.VR6DoF:
                break;
        }
    }

    @Override
    public boolean triggerVibrator(int axis, long durationms, int intensity) {
        return true;
    }

    @Override
    public boolean getBoolean(int property, AttributeError error) {
        boolean result = false;

        switch (property) {
        case WVR.Attr_Is6DoFTracking_Bool:
            result = true;
            break;

        case WVR.Attr_IsHWRecenter_Bool:
            result = true;
            break;

        default:
            error.setResult(AttributeError.Unknown);
            break;
        }

        return result;
    }

    @Override
    public float getFloat(int property, AttributeError error) {
        error.setResult(AttributeError.SUCCESS);

        switch (property) {
        case WVR.Attr_DeviceBatteryPercentage_Float:
            return 1;
        }

        error.setResult(AttributeError.NotSupported);
        return 0;
    }

    @Override
    public int getInt(int property, AttributeError error) {
        error.setResult(AttributeError.SUCCESS);

        switch (property) {
        case WVR.Attr_BatteryStatus_Int32:
            return 1;
        }

        error.setResult(AttributeError.NotSupported);
        return 0;
    }

}
