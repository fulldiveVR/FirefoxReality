package htc.com.vr.sample.simpledevice;

import com.htc.vr.sdk.pluginkit.VRDevice;
import com.htc.vr.sdk.pluginkit.VRDeviceService;

import java.util.Vector;


public class ControllerService extends VRDeviceService {
    @Override
    public void onCreate() {
        super.onCreate();
        Vector<VRDevice> devices = new Vector<>();
        devices.add(new MyControllerDevice());
        devices.add(new MyControllerDevice());
        for (VRDevice device : devices) {
            registerDevice(device);
            device.connect();
        }
    }
}
