package htc.com.vr.sample.simpledevice;

import com.htc.vr.sdk.WVR;
import com.htc.vr.sdk.pluginkit.ExternalTracker;

public class MyTrackerDevice extends ExternalTracker {
    public MyTrackerDevice() {
        super();
        connect();
    }

    @Override
    public void onStart() {
        Utils.Log("onStart");
    }

    @Override
    public void onStop() {
        Utils.Log("onStop");
    }

    Config configure;
    @Override
    public Config setupConfig() {
        if (configure == null) {
            configure = new Config();
            configure.trackingSystemName = "Simple_LED_Marker";
            configure.trackerType = WVR.ExternalTrackerType_Observer;
        }
        return configure;
    }

}
