package htc.com.vr.sample.simpledevice;

import com.htc.vr.sdk.WVR;
import com.htc.vr.sdk.Pose;
import com.htc.vr.sdk.Quaternion;
import com.htc.vr.sdk.Vector;
import com.htc.vr.sdk.pluginkit.HmdDevice;
import com.htc.vr.sdk.pluginkit.AttributeError;
import android.util.Log;

class MyHmdDevice extends HmdDevice {
    protected boolean mIsRunning;
    final Pose mPose = new Pose();
    Thread mThread;
    final Runnable mPoseRunnable = new Runnable() {
        @Override
        public void run() {
            while (mIsRunning) {
                mPose.translation.x += 0.00001;
                if (mPose.translation.x > 3)
                    mPose.translation.x = -3;

                mPose.rotation.x += 0.01;
                if (mPose.rotation.x > 3)
                    mPose.rotation.x = -3;

                mPose.angularVelocity.y++;
                if (mPose.angularVelocity.y > 3000)
                    mPose.angularVelocity.y = -3000;

                updatePose(mPose, System.nanoTime());
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    public MyHmdDevice() {
        super();
        connect();
        mPose.translation = new Vector();
        mPose.rotation = new Quaternion();
        mPose.rotation.w = 1;
        mPose.angularVelocity = new Vector();
    }

    @Override
    public void onStart() {
        //mSensorManager.registerListener(this, mAccelerometer, mMinSensorDelay);
        mIsRunning = true;
        mPose.translation.x = 2.9;
        mPose.rotation.x = 1;
        mThread =  new Thread(mPoseRunnable);
        mThread.start();

    }

    @Override
    public void onStop() {
        Utils.Log("");
        mIsRunning = false;
        try {
            mThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onPause() {
        Utils.Log("");
        mIsRunning = false;
        try {
            mThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onResume() {
        if (!mIsRunning) {
            mIsRunning = true;
            mThread =  new Thread(mPoseRunnable);
            mThread.start();
        }
    }

    @Override
    public Config setupConfig() {
        Config configure = new Config();
        configure.trackingSystemName = "HMD Device";
        configure.modelNumber = "";
        configure.containsProximitySensor = true;
        configure.hasCamera = true;
        configure.containsRecenter = false;
        configure.contains6Dof = true;
        configure.trackingModelType = 0x00AF0000;
        configure.screenOrientation = WVR.ScreenOrientation_Landscape;
        configure.scanlineType = WVR.ScanlineType_LeftToRight;
        configure.deviceProvidesBatteryStatus = true;
        int support = 0;
        configure.supportedButton = support;
        support = 0;
        configure.supportedTouch = support;

        return configure;
    }

    @Override
    public void onTrackingModeChanged(int mode) {
        switch (mode) {
            case WVR.TrackingMode.VR3DoF:
                break;
            case WVR.TrackingMode.VR6DoF:
                break;
        }
    }

    @Override
    public long getLong(int property, AttributeError error) {
        long ret = 1;
        error.setResult(AttributeError.SUCCESS);

        switch (property) {
            case WVR.Attr_6DofWorkArea_Uint64:
                break;
            default:
                ret = super.getLong(property, error);
                break;
        }
        return ret;
    }

    @Override
    public float getFloat(int property, AttributeError error) {
        float ret = 1;
        error.setResult(AttributeError.SUCCESS);

        switch (property) {

            case WVR.Attr_DeviceBatteryPercentage_Float:
                break;

            case WVR.Attr_BatteryTemperature_Float:
                break;

            default:
                error.setResult(AttributeError.NotSupported);
                return ret;
        }
        return ret;
    }

    @Override
    public int getInt(int property, AttributeError error) {
        int ret = 1;
        error.setResult(AttributeError.SUCCESS);

        switch (property) {
            case WVR.Attr_BatteryStatus_Int32:
                break;
            case WVR.Attr_ChargeStatus_Int32:
                break;
            case WVR.Attr_BatteryTemperatureStatus_Int32:
                break;
            default:
                error.setResult(AttributeError.NotSupported);
                return ret;
        }
        return ret;
    }

    @Override
    public boolean getBoolean(int property, AttributeError error) {

        if (WVR.Attr_IsHWRecenter_Bool == property) {
            error.setResult(AttributeError.SUCCESS);
            return false;
        }

        error.setResult(AttributeError.NotSupported);
        return false;
    }

    @Override
    public float[][] getMatrix(int property, AttributeError error) {
        error.setResult(AttributeError.SUCCESS);

        return super.getMatrix(property, error);
    }

    @Override
    public String getString(int property, AttributeError error) {
        error.setResult(AttributeError.SUCCESS);

        return super.getString(property, error);
    }

}
