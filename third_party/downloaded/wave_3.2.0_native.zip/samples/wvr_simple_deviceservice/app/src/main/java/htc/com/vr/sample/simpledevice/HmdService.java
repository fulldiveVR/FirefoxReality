package htc.com.vr.sample.simpledevice;

import com.htc.vr.sdk.pluginkit.VRDevice;
import com.htc.vr.sdk.pluginkit.VRDeviceService;

import java.util.Vector;


public class HmdService extends VRDeviceService {
    @Override
    public void onCreate() {
        super.onCreate();
        VRDevice device = new MyHmdDevice();
        registerDevice(device);
    }
}
