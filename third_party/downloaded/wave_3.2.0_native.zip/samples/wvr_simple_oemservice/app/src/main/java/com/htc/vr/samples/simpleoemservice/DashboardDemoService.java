
package com.htc.vr.samples.simpleoemservice;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import com.htc.vr.sdk.VREventType;
import com.htc.vr.sdk.VRInputId;
import android.os.Handler;
import java.lang.Thread;
import com.htc.vr.sdk.overlay.VROverlayParams;
import com.htc.vr.sdk.overlay.VROverlayService;
import com.htc.vr.sdk.overlay.VROverlayType;
import com.htc.vr.sdk.overlay.VRSystemDialogOverlay;
import android.os.Looper;
import com.htc.vr.sdk.overlay.VRTypes;
import android.os.Build;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;

// adb shell am startservice -n com.htc.vr.samples.simpleoemservice/.DashboardDemoService  --ei WORK_COMMAND 1
public class DashboardDemoService extends VROverlayService
{
    private final String TAG="DashboardDemoService";
    private VRSystemDialogOverlay mHvrOverlay;
    private boolean mIsShowed= false;
    private boolean mOverlayReady = false;
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private LinearLayout.LayoutParams mLayoutParams;
    private LinearLayout mLauncherLayout;
    public void onCreate() {
        Log.d(this.TAG, "DashboardDemoService() start...");
        super.onCreate();
        createView();
    }

    @Override
    public int onStartCommand(Intent intent,int flags, int startId){
        setToForeground();
        stopForeground(true);
        int command=intent.getIntExtra("WORK_COMMAND",0);
        if(command == 1){
            mHandler.post(new Thread(delaySeconds));
        }
        else if(command == 0){
            hideDashboard();
        }
        return super.onStartCommand(intent, flags, startId);
    }

    protected void onVROverlayResume(){
        Log.d(this.TAG, "onVROverlayResume() start...");
        super.onVROverlayResume();
        mOverlayReady = true;
        mHvrOverlay = (VRSystemDialogOverlay) getVROverlay(new VROverlayParams(new VROverlayType(VROverlayType.TYPE_SYSTEMDIALOGOVERLAY)));
        mHvrOverlay.setOverlayInputType(VRInputId.Touchpad);
        mHvrOverlay.setOnOutOfBoundListener(new VRSystemDialogOverlay.OnOutOfBoundListener() {
            @Override
            public void onOutOfBoundListener(final int type, final int inputId, final int deviceIndex){
                Log.d(TAG, "call onOutOfBoundListener type=" + type + " inputId=" + inputId);
                if(inputId == VRTypes.WVR_InputId_Touchpad || inputId == VRTypes.WVR_InputId_Enter){
                    if(type == VRTypes.WVR_EventType_ButtonUnpressed) hideDashboard(); 
                }
            }
        });
    }

    protected void onVROverlayPause(){
        Log.d(this.TAG, "onVROverlayPause() start...");
        super.onVROverlayPause();
        mOverlayReady = false;
    }

    @Override
    protected synchronized void onButton(final int type, final int inputId, final int deviceId){
        Log.d(TAG, "call onButtonEvent type =" + type + " inputid =" + inputId);
        super.onButton(type, inputId, deviceId);
        switch(inputId){
            case VRTypes.WVR_InputId_Back:
                if(type == VRTypes.WVR_EventType_ButtonPressed){
                    Log.d(TAG, "on WVR_InputId_Back event VR_EventType_ButtonPressed");
                }
                else if(type == VRTypes.WVR_EventType_ButtonUnpressed){
                    Log.d(TAG, "on WVR_InputId_Back event WVR_EventType_ButtonUnpressed");
                }
            break;
            case VRTypes.WVR_InputId_Enter:
                Log.d(TAG, "on WVR_InputId_Enter event");
            break;
            case VRTypes.WVR_InputId_Menu:
                if(type == VRTypes.WVR_EventType_ButtonPressed){
                    Log.d(TAG, "on WVR_InputId_Menu event VR_EventType_ButtonPressed");
                }
                else if(type == VRTypes.WVR_EventType_ButtonUnpressed){
                    Log.d(TAG, "on WVR_InputId_Menu event WVR_EventType_ButtonUnpressed");
                }
                /*
                  if(!mIsShowed) showDashboard();
                  else hideDashboard();
                */
            break;
        }
    }

    public IBinder onBind(Intent intent){
        return null;
    }

    private void createView(){
        Log.d(TAG, "createView");
        mLayoutParams = new LinearLayout.LayoutParams(880, 440);
        mLauncherLayout = (LinearLayout) ((LayoutInflater) this.getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.dashboard_launcher,null);
        mLauncherLayout.setLayoutParams(mLayoutParams);
        Button button= (Button) mLauncherLayout.findViewById(R.id.btn_test_on_off);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button btn= (Button) v;
                String text=btn.getText().toString();
                Log.d(TAG, "onClick text =" + text);
                if(text.equals("ON")){
                    btn.setText("OFF");
                }
                else{
                    btn.setText("ON");
                }
            }
        });
    }

    private void showDashboard(){
        Log.d(TAG, "call showDashboard");
        if(mHvrOverlay == null) return;
        mHvrOverlay.showOverlay(mLauncherLayout);
        mHvrOverlay.setOverlayFixedPosition(new double[]{0, 0, -0.98});
        mHvrOverlay.setOverlayInputType(VRInputId.Touchpad);
        mIsShowed = true;
        mHvrOverlay.setOnOutOfBoundListener(new VRSystemDialogOverlay.OnOutOfBoundListener() {
            @Override
            public void onOutOfBoundListener(final int type, final int inputId, final int deviceIndex){
                Log.d(TAG, "call onOutOfBoundListener type=" + type + " inputId=" + inputId);
                if(inputId == VRTypes.WVR_InputId_Touchpad || inputId == VRTypes.WVR_InputId_Enter){
                    if(type == VRTypes.WVR_EventType_ButtonUnpressed) hideDashboard(); 
                }
            }
        });
    }

    private void hideDashboard(){
        Log.d(TAG, "call hideDashboard");
        if(mHvrOverlay == null) return;
        mHvrOverlay.hideOverlay();
        mIsShowed = false;
        mHvrOverlay.setOnOutOfBoundListener(null);
    }

    private Runnable delaySeconds = new Runnable() {
        @Override
        public void run() {
            if (!mOverlayReady) {
                Log.d(TAG, "delay seconds 500");
                mHandler.postDelayed(delaySeconds, 500);
            } else {
                Log.d(TAG, "overlay is ready, Show Overlay");
                showDashboard();
            }
        }
    };

    public void onDestroy(){
        super.onDestroy();
    }

    private void setToForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.d(TAG, "setToForeground()");
            try {
                String CHANNEL_ID = "channel.id.oemservice.DashboardDemoService";
                int NOTIFICATION_ID = 1230;
                NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Notifications", NotificationManager.IMPORTANCE_NONE);
                notificationManager.createNotificationChannel(channel);

                Notification.Builder builder = new Notification.Builder(getApplicationContext(), CHANNEL_ID)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setCategory(Notification.CATEGORY_SERVICE);
                startForeground(NOTIFICATION_ID, builder.build());
            } catch (Exception e) {
                Log.e(TAG, e.toString());
            }
        }
    }
}
