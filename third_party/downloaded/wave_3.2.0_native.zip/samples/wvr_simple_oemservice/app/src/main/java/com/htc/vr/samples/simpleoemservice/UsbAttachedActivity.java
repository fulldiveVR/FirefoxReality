// ++ LICENSE-HIDDEN SOURCE ++

package com.htc.vr.samples.simpleoemservice;

import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.app.Activity;
import android.app.ActivityManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.net.Uri;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.ContentResolver;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;

import android.database.Cursor;
import java.util.List;
import java.util.ArrayList;

import com.htc.vr.samples.simpleoemservice.R;

public class UsbAttachedActivity extends AppCompatActivity {
    private static final String TAG = "UsbAttachedActivity";
    private static final String OEMSERVICE_ACTION = "vive.wave.action.VROEMSERVICE";
    private static final String DB_HMD_SERVICE = "auth_hmd";
    private static final String SUPPORT_COMPOUND = "supportCP";
    private static final String VRDATA_READ = "com.htc.vr.core.server.VRDataRead";
    private Context mContext;
    private String mSupportDS,mSupportLCPK,mSupportLCAC;
    private String mAuthDs;
    private String mOemPackageName;
    private String mOemClassName;
    private boolean mDoLaunch = false;
    private MyCPList mCPList = new MyCPList();
    private Handler mHandler = null;
    private Runnable mCheckInfoAsync = new Runnable() {
        @Override
        public void run() {
            getInfo(mContext);
            // first check ds
            if (!isSupportDs()) {
                Log.d(TAG, "run: not support ds");
            } else { // if support then check if oem service is running
                Log.d(TAG, "run: initOem");
                initOem(mContext);
                if (isServiceRunning(mOemClassName)) {
                    Log.d(TAG, "run: server is running");
                } else { // if oem service not running -> do Launch
                    Log.d(TAG, "run: server not run -> launchVRHome");
                    mDoLaunch = true;
                }
            }
            runOnUiThread(new Runnable() {
                public void run() {
                    release();// finish self
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate: start");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usb_attached);
        mContext = this;
        HandlerThread thread = new HandlerThread(UsbAttachedActivity.class.getSimpleName() + " Thread");
        thread.start();
        mHandler = new Handler(thread.getLooper());
        mHandler.post(mCheckInfoAsync);
        Log.d(TAG, "onCreate: end");
    }

    private void getInfo(Context context) {
        if (context == null) {
            Log.d(TAG, "getInfo param null !");
            return;
        }
        // Read Auth DS from DB
        mAuthDs = readServerDS(context);
        // get info from meta of AndroidManifest
        getSelfActivityInfo(context);
    }

    private boolean isSupportDs() {
        // check from mCPList
        if (mAuthDs != null && !mAuthDs.isEmpty()) {
            for (MyCP cp : mCPList.getList()) {
                if (mAuthDs.contains(cp.getDSPK())) {
                    mSupportDS = mAuthDs;
                    mSupportLCPK = cp.getLCPK();
                    mSupportLCAC = cp.getLCAC();
                    Log.d(TAG, "isSupportDs mSupportDS = " + mSupportDS);
                    Log.d(TAG, "isSupportDs mSupportLCPK = " + mSupportLCPK);
                    Log.d(TAG, "isSupportDs mSupportLCAC = " + mSupportLCAC);
                    return true;
                }
            }
        }
        return false;
    }

    private void getSelfActivityInfo(Context context) {
        if (context == null) {
            return;
        }
        try {
            ComponentName cpName = this.getComponentName();
            Log.d(TAG, "getSelfActivityInfo pkName = " + context.getPackageName());
            Log.d(TAG, "getSelfActivityInfo cpName = " + cpName.toString());
            ActivityInfo ai = context.getPackageManager().getActivityInfo(cpName, PackageManager.GET_META_DATA);
            Bundle bundle = ai.metaData;
            getSupportCompound(bundle);
        } catch (Exception ex) {
            Log.d(TAG, "getSelfActivityInfo Exception " + ex.toString());
        }
    }

    private void getSupportCompound(Bundle bundle) {
        String strMetaCP = bundle.getString(SUPPORT_COMPOUND);
        Log.d(TAG, "getSupportCompound strMetaCP = " + strMetaCP);
        mCPList.initFromMeta(strMetaCP);
    }

    private boolean checkDBPermission() {
        boolean res = false;
        if (ContextCompat.checkSelfPermission(this, VRDATA_READ) == PackageManager.PERMISSION_GRANTED) {
            res = true;
        }
        return res;
    }

    private String readServerDS(Context context) {
        Log.d(TAG, "readServerDS : start");
        String name = DB_HMD_SERVICE;
        String result = null;
        if (checkDBPermission() && context != null) {
            try {
                String selectionClause = new String("name = ?");
                String[] selectionArgs = new String[] {name};
                Uri uri = Uri.parse("content://vr_data2/Auth");
                String[] projection = {"value"};
                Cursor cur = context.getContentResolver().query(uri, projection , selectionClause, selectionArgs , null);
                if (cur.moveToNext() ) {
                    Log.d(TAG, "Get Device Service Data Success : " + cur.getString(1));
                    result = cur.getString(1);
                } else {
                    Log.d(TAG, "Get Device Service Data Failed");
                }
                return result;
            } catch (Exception ex) {
                Log.d(TAG,"readServerDS:" + ex.toString());
            }
        } else {
            Log.d(TAG, "readServerDS() has no Server DB permission");
        }
        return result;
    }

    private boolean isServiceRunning(String serviceClassName) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> services = manager.getRunningServices(Integer.MAX_VALUE);
        int i = 0;
        Log.d(TAG, "isServiceRunning => check : " + serviceClassName);
        for (ActivityManager.RunningServiceInfo info : services) {
            Log.d(TAG, "isServiceRunning => run " + i + " : " + info.service.getClassName());
            i++;
            if (serviceClassName.equals(info.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    private void initOem(Context context) {
        Log.d(TAG, "initOem");
        PackageManager pm = context.getPackageManager();
        Intent intent = new Intent();
        intent.setPackage(context.getPackageName());
        intent.setAction(OEMSERVICE_ACTION);
        final List<ResolveInfo> resolveInfoList = pm.queryIntentServices(intent, PackageManager.GET_SERVICES);
        if (resolveInfoList.size() > 0) {
            Log.d(TAG, "Found " + resolveInfoList.size() + " VROEM service in this device.");
            if (resolveInfoList.size() > 1) {
                Log.w(TAG, "There are more than one VROEM service in this device.");
            }
            for (ResolveInfo resolve : resolveInfoList) {
                Log.d(TAG, "VRAssist Service Package: " + resolve.serviceInfo.packageName +
                    ", Class: " + resolve.serviceInfo.name);
            }
            mOemPackageName = resolveInfoList.get(0).serviceInfo.packageName;
            mOemClassName = resolveInfoList.get(0).serviceInfo.name;
            Log.d(TAG, "initOem OemPackageName: " + mOemPackageName);
            Log.d(TAG, "initOem OemClassName: " + mOemClassName);
        } else {
            Log.w(TAG, "Cannot find VROEM service in this device.");
        }
    }

    private void launchVRHome(Context context) {
        if (mSupportLCPK != null && mSupportLCAC != null && context != null) {
            Log.d(TAG, "launchVRHome");
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.setClassName(mSupportLCPK, mSupportLCAC);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(intent);
            } catch (ActivityNotFoundException ex) {
                Log.i(TAG, "ActivityNotFoundException: " + ex.getMessage());
            }
        }
    }

    private void release() {
        Log.d(TAG, "release call finish");
        finish();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy: start");
        super.onDestroy();
        if (mDoLaunch) {
            launchVRHome(mContext);
        }

        if (mHandler != null) {
            mHandler.getLooper().quitSafely();
        }
        Log.d(TAG, "onDestroy: end");
    }

    private class MyCP {
        private String dspk;
        private String lcpk;
        private String lcac;
        public MyCP() {}
        public MyCP(String dpk, String lpk, String lac) {
            this.dspk = dpk;
            this.lcpk = lpk;
            this.lcac = lac;
        }

        public MyCP clone() {
            MyCP returnCP = new MyCP(this.dspk, this.lcpk, this.lcac);
            return returnCP;
        }

        public void setDSPK(String dpk) {
            this.dspk = dpk;
        }

        public void setLCPK(String lpk) {
            this.lcpk = lpk;
        }

        public void setLCAC(String lac) {
            this.lcac = lac;
        }

        public String getDSPK() {
            return this.dspk;
        }

        public String getLCPK() {
            return this.lcpk;
        }

        public String getLCAC() {
            return this.lcac;
        }
    }

    private class MyCPList {
        private ArrayList<MyCP> mList = new ArrayList<MyCP>();
        public MyCPList() {}
        public void initFromMeta(String meta) {
            Log.d(TAG, "initFromMeta ->");
            /* meta-data format in AndroidManifest.xml
            <meta-data android:name="supportCP"
                android:value="DSPackage1|LauncherPackage1|LauncherActivity1,
                               DSPackage2|LauncherPackage2|LauncherActivity2" />*/
            String[] compounds = meta.split("\\,", 0);
            int nth = 0;
            for (String compound : compounds) {
                MyCP tmpMyCP = new MyCP();
                String[] infos = compound.split("\\|",0);
                int index = 0;
                for (String info : infos) {
                    String tmpStr = info.replaceAll("\\s+",""); //remove space
                    Log.d(TAG, nth + " th parse info: " + tmpStr);
                    switch (index) {
                        case 0:
                            tmpMyCP.setDSPK(tmpStr);
                            break;
                        case 1:
                            tmpMyCP.setLCPK(tmpStr);
                            break;
                        case 2:
                            tmpMyCP.setLCAC(tmpStr);
                            break;
                    }
                    index++;
                }
                mList.add(tmpMyCP);
                nth++;
            }            
            Log.d(TAG, "initFromMeta <-");
        }

        public ArrayList<MyCP> getList() {
            ArrayList<MyCP> returnList = new ArrayList<MyCP>();
            for (MyCP cp : this.mList) {
                 returnList.add((MyCP)cp.clone());
            }
            return returnList;
        }
    }
}
