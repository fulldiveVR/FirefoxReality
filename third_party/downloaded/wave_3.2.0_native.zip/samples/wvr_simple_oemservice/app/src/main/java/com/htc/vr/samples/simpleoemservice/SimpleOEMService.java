// "WaveVR SDK 
// © 2017 HTC Corporation. All Rights Reserved.
//
// Unless otherwise required by copyright law and practice,
// upon the execution of HTC SDK license agreement,
// HTC grants you access to and use of the WaveVR SDK(s).
// You shall fully comply with all of HTC’s SDK license agreement terms and
// conditions signed by you and all SDK and API requirements,
// specifications, and documentation provided by HTC to You."

package com.htc.vr.samples.simpleoemservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import vive.wave.vr.oem.lib.IVROEMService;


public class SimpleOEMService extends Service {
    private static final String TAG = "SimpleOEMService";

    private SimpleOEMService_api1 mServiceApi1;

    public SimpleOEMService() {
        mServiceApi1 = new SimpleOEMService_api1(this);
    }

    private final IVROEMService.Stub mBinder = new IVROEMService.Stub() {
        @Override
        public int getMinApiVersion() throws RemoteException {
            return 1;
        }

        @Override
        public int getMaxApiVersion() throws RemoteException {
            return 1;
        }

        @Override
        public IBinder getApi(int version) throws RemoteException {
            switch (version) {
                case 1:
                    return mServiceApi1;
            }
            return null;
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG,"onBind");
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        boolean ret = super.onUnbind(intent);
        Log.d(TAG, "onUnbind: intent=" + intent);
        return ret;
    }
}
