package com.htc.vr.samples.simpleoemservice;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import android.os.Build;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;


import com.htc.vr.sdk.overlay.VRCustomizeOverlay;
import com.htc.vr.sdk.overlay.VROverlayError;
import com.htc.vr.sdk.overlay.VROverlayParams;
import com.htc.vr.sdk.overlay.VROverlayService;
import com.htc.vr.sdk.overlay.VROverlayType;
import com.htc.vr.sdk.overlay.VRSystemDialogOverlay;



public class SimpleControllerOverlayService extends VROverlayService {

    private final static String TAG = "SimpleControllerOverlayService";
    private VRCustomizeOverlay mOverlay;
    private RelativeLayout mRoot;
    private Handler mHandler=null;
    private boolean mIsNeedShow = false;
    private boolean overlayReady = false;

    public static final String CONNECTION_STATE = "com.htc.vr.simpleoemservice.CONNECTION_STATE";


    @Override
    public void onCreate() {
        Log.v(TAG, "onCreate");
        super.onCreate();
        mHandler= new Handler(Looper.getMainLooper());
    }

    @Override
    public void onDestroy() {
        Log.v(TAG, "onDestroy");
        super.onDestroy();
        if (mOverlay != null) {
            mOverlay.hideOverlay();
            mOverlay = null;
        }
    }

    @Override
    protected void onVROverlayResume()
    {
        Log.i(TAG,"onVROverlayResume()");
        super.onVROverlayResume();

        mOverlay = (VRCustomizeOverlay) getVROverlay(new VROverlayParams(new VROverlayType(VROverlayType.TYPE_CUSTOMIZEOVERLAY)));
        double[] matrix = new double[] { 0.0f, 0.0f, -1.013f};
        mOverlay.setOverlayFixedPosition(matrix);

        overlayReady = true;
        if(mIsNeedShow) {
            handler.postDelayed(delaySeconds, 500);
        }

    }

    private void show() {
        Log.i(TAG, "show()");
        if(overlayReady){
            handler.post(delaySeconds);
        }
    }

    private Runnable delaySeconds = new Runnable() {
        @Override
        public void run() {
            if (!overlayReady) {
                //Log.d(TAG, "overlay is not ready, wait 0.5 sec");
                handler.postDelayed(delaySeconds, 500);
            } else {
                Log.d(TAG, "overlay is ready, Show Overlay");
                if (mRoot != null && mOverlay != null) {
                    VROverlayError err = mOverlay.showOverlay(mRoot);
                    Log.i(TAG, "showOverlay ret " + err);
                }
            }
        }
    };

    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onVROverlayPause() {
        Log.i(TAG,"onVROverlayPause()");
        overlayReady = false;
        super.onVROverlayPause();
    }

    private void hide() {
        Log.i(TAG, "hide()");
        if (mOverlay != null) {
            mOverlay.hideOverlay();
        }
    }

    @Override
    public void onVROverlayDestroy() {
        Log.i(TAG,"onVROverlayDestroy()");
        hide();
        super.onVROverlayDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.i(TAG, "onBind()");
        return super.onBind(intent);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.i(TAG, "onUnbind()");
        return super.onUnbind(intent);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "onStartCommand startId: " + startId + " Intent: " + intent);
        setToForeground();
        stopForeground(true);
        if (intent != null) {
            boolean bConnected = intent.getBooleanExtra(CONNECTION_STATE, false);
            LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
            mRoot = (RelativeLayout) inflater.inflate(R.layout.controller_disconnect_layout,null);
            mIsNeedShow = !bConnected;
            if (bConnected) {
                hide();
            } else {
                show();
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }

    private void setToForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.d(TAG, "setToForeground()");
            try {
                String CHANNEL_ID = "channel.id.oemservice.SimpleControllerOverlayService";
                int NOTIFICATION_ID = 1230;
                NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Notifications", NotificationManager.IMPORTANCE_NONE);
                notificationManager.createNotificationChannel(channel);

                Notification.Builder builder = new Notification.Builder(getApplicationContext(), CHANNEL_ID)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setCategory(Notification.CATEGORY_SERVICE);
                startForeground(NOTIFICATION_ID, builder.build());
            } catch (Exception e) {
                Log.e(TAG, e.toString());
            }
        }
    }

}
