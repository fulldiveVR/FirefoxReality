// "WaveVR SDK 
// © 2017 HTC Corporation. All Rights Reserved.
//
// Unless otherwise required by copyright law and practice,
// upon the execution of HTC SDK license agreement,
// HTC grants you access to and use of the WaveVR SDK(s).
// You shall fully comply with all of HTC’s SDK license agreement terms and
// conditions signed by you and all SDK and API requirements,
// specifications, and documentation provided by HTC to You."

package com.htc.vr.samples.simpleoemservice;

import android.content.Context;
import android.graphics.PointF;
import android.os.RemoteException;
import android.util.Log;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Bundle;
import android.os.Looper;
import android.os.Message;
import android.content.Intent;

import java.util.Locale;

import vive.wave.vr.oem.lib.IVROEMService_api1;
import vive.wave.vr.oem.lib.IVROEMClient_api1;
import vive.wave.vr.oem.lib.RecenterType;
import vive.wave.vr.oem.lib.VRDeviceType;
import vive.wave.vr.oem.lib.VRValidationResult;
import vive.wave.vr.oem.lib.VRInputId;
import vive.wave.vr.oem.lib.VROEMEvent;
import vive.wave.vr.oem.lib.VRServerState;
import com.htc.vr.sdk.overlay.VRTypes;
import android.os.Build;

public final class SimpleOEMService_api1 extends IVROEMService_api1.Stub {
    private static final String TAG = "SimpleOEMService_api1";
    private final String SELF = String.format("(%s@%X)", getClass().getSimpleName(), hashCode());

    private SimpleOEMService mOwner;
    private IBinder mClientBinder = null;
    private Record mClientRecord = null;
    private VRServerState mVRServerState = VRServerState.VRServerState_STOP;
    private VRValidationResult mValidationResult = null;
    private boolean mStartWithoutHMD = false;
    private boolean mHMDHasPSensor = false;

    private static final int EVENT_CHECK_ENVIRONMENT                   = 1;
    private static final int EVENT_SET_ACTIVITY_LEVEL                  = 2;
    private final String PACKAGE_NAME = "com.htc.vr.samples.simpleoemservice";

    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            Log.d(TAG, "handleMessage " + msg.what);
            switch (msg.what) {
                case EVENT_CHECK_ENVIRONMENT:
                    doEnvironmentCheck();
                    break;
                case EVENT_SET_ACTIVITY_LEVEL:
                    Log.d(TAG, "Set activity level to " + msg.arg1);
                    setActivityLevel(msg.arg1);  // 0: Idle; 1: Active; 2: Active Timeout; 3: Standby
                    break;
            }
        }
    };

    public SimpleOEMService_api1(SimpleOEMService owner) {
        mOwner = owner;
    }

    private synchronized void finishVRAP(boolean bKillAll) {
        Log.i(TAG, "finishVRAP()");
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            client.finishVRAP(bKillAll);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
    }

    private synchronized void broadcastServerReady(VRValidationResult result) {
        Log.i(TAG, String.format("broadcastServerReady: hasExternalDisplay=%b", result.getHasExternalDisplay()));
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            client.broadcastServerReady(result);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
    }

    private synchronized boolean hasExternalDisplay() {
        Log.d(TAG, "hasExternalDisplay()");
        boolean hasExtDisplay = false;
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            hasExtDisplay = client.hasExternalDisplay();
            Log.i(TAG, "client: " + client + " has EXTERNAL display: " + hasExtDisplay);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return hasExtDisplay;
    }

    private synchronized boolean hasProximitySensor() {
        Log.d(TAG, "hasProximitySensor()");
        boolean hasPSensor = false;
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            hasPSensor = client.hasProximitySensor();
            Log.i(TAG, "client: " + client + " has proximity sensor: " + hasPSensor);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return hasPSensor;
    }

    private synchronized float getHmdBatteryPercentage() {
        Log.d(TAG, "getHmdBatteryPercentage()");
        float percentage = 0;
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            percentage = client.getHmdBatteryPercentage();
            Log.i(TAG, "client: " + client + " battery percentage: " + percentage);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return percentage;
    }

    private synchronized float getHmdBatteryTemperature() {
        Log.i(TAG, "getHmdBatteryTemperature()");
        float temperature = 0;
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            temperature = client.getHmdBatteryTemperature();
            Log.i(TAG, "client: " + client + " battery temperature: " + temperature);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return temperature;
    }

    private synchronized int getConnectedCountrollerCount() {
        Log.i(TAG, "getConnectedCountrollerCount()");
        int count = 0;
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            count = client.getConnectedCountrollerCount();
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return count;
    }

    private synchronized void triggerRecenter(RecenterType type) {
        Log.i(TAG, "triggerRecenter()");
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            client.triggerRecenter(type);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
    }

    private synchronized void setActivityLevel(int level) {
        Log.i(TAG, "setActivityLevel()");
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            client.setActivityLevel(level);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
    }

    private synchronized boolean isHMDConnected() {
        Log.d(TAG, "isHMDConnected()");
        boolean bConnected = false;
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            bConnected = client.isHMDConnected();
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return bConnected;
    }

    private synchronized String getParameters(int devId, String params) {
        Log.d(TAG, "getParameters()");
        String strParam = "";
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            strParam = client.getParameters(devId, params);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return strParam;
    }

    private synchronized int getDevicePropertyStatus(int device_id,int property){
        Log.d(TAG, "getDevicePropertyStatus()");
        int status = -1;
        IVROEMClient_api1 client = IVROEMClient_api1.Stub.asInterface(mClientBinder);
        try {
            status = client.getDevicePropertyStatus(device_id, property);
        } catch (RemoteException ex) {
            // remote is dead; we will receive binderDied
            ex.printStackTrace();
        }
        return status;
    }

    @Override
    public String getApiVersion() throws RemoteException {
        return BuildConfig.VERSION_NAME;
    }

    class Record implements IBinder.DeathRecipient {
        IVROEMClient_api1 client;
        final int pid;
        final int uid;
        final String name;

        Record(IVROEMClient_api1 c) {
            this.client = c;
            this.pid = Binder.getCallingPid();
            this.uid = Binder.getCallingUid();
            this.name = mOwner.getPackageManager().getNameForUid(uid);
        }

        @Override
        public void binderDied() {
            Log.v(TAG, "binderDied: client=" + this);
            synchronized (SimpleOEMService_api1.this) {
                mClientBinder.unlinkToDeath(mClientRecord, 0);
                mClientBinder = null;
                mClientRecord = null;
            }
        }

        @Override
        public String toString() {
            return String.format(Locale.US,
                    "(pid=%d, uid=%d, name=%s)@%x",
                    pid, uid, name, client.asBinder().hashCode());
        }
    }

    @Override
    public synchronized void registerClient(IVROEMClient_api1 client) {
        Log.i(TAG, SELF + " registerClient");
        IBinder token = client.asBinder();
        if (mClientBinder!= null && mClientBinder != token) {
            mClientBinder.unlinkToDeath(mClientRecord, 0);
            mClientRecord = null;
        }

        mClientBinder = token;
        mClientRecord = new Record(client);

        try {
            mClientBinder.linkToDeath(mClientRecord, 0);
        } catch (RemoteException ex) {
            // already dead; skip adding this client
            Log.i(TAG, ex.toString());
            return;
        }
    }

    @Override
    public synchronized void unregisterClient(IVROEMClient_api1 client) {
        Log.i(TAG, SELF + " unregisterClient");
        IBinder token = client.asBinder();
        if (mClientBinder != token) {
            Log.e(TAG, "token " + token + "is not registered");
            return;
        }

        mClientBinder.unlinkToDeath(mClientRecord, 0);
        mClientBinder = null;
        mClientRecord = null;
    }

    @Override
    public synchronized void start(IVROEMClient_api1 client) {
        Log.i(TAG, SELF + " start");
        IBinder token = client.asBinder();
        if (mClientBinder != token) {
            Log.e(TAG, "token " + token + "is not registered");
            return;
        }

        Message msg = mHandler.obtainMessage(EVENT_CHECK_ENVIRONMENT);
        msg.sendToTarget();
    }

    @Override
    public synchronized void stop(IVROEMClient_api1 client) {
        Log.i(TAG, SELF + " stop");
        IBinder token = client.asBinder();
        if (mClientBinder != token) {
            Log.e(TAG, "token " + token + "is not registered");
            return;
        }

        mValidationResult = null;
        mVRServerState = VRServerState.VRServerState_STOP;
        mStartWithoutHMD = false;
    }

    @Override
    public synchronized void notifyClientForeground(boolean foreground) {
        Log.d(TAG, SELF + " notifyClientForeground foreground: " + foreground);
    }

    @Override
    public synchronized void notifyClientFocused(boolean focused) {
        Log.d(TAG, SELF + " notifyClientFocused focused: " + focused);
    }

    @Override
    public synchronized void notifyFotaRunning(boolean running) {
        Log.d(TAG, "notifyFotaRunning. running: " + running);
        if (running) {
            // Inform runtime server to close all VR Apps
            finishVRAP(true);
        }
    }

    @Override
    public synchronized void notifyProximityTriggered(boolean bTriggered) {
        Log.d(TAG, "notifyProximityTriggered: Triggered(" + bTriggered + ")");
        if (bTriggered && mHMDHasPSensor) {
            Message msg = mHandler.obtainMessage(EVENT_SET_ACTIVITY_LEVEL);
            msg.arg1 = 1;  // Set activity level l means active.
            msg.sendToTarget();
        }
    }

    @Override
    public void onEvent(VROEMEvent event) {
        Log.d(TAG, "onEvent type(" + event.getEventType().getValue() +"), device(" + event.getDeviceType().getValue() + "), tracker(" + event.getExternalTrackerType().getValue() + ")");
        Log.d(TAG, "onEvent mStartWithoutHMD:" + mStartWithoutHMD);
        if (mStartWithoutHMD) {
            if ((event.getEventType() == VROEMEvent.VREventType.VREventType_DeviceConnected)
                    && (event.getDeviceType() == VRDeviceType.VRDeviceType_HMD)) {
                mStartWithoutHMD = false;
                Message msg = mHandler.obtainMessage(EVENT_CHECK_ENVIRONMENT);
                msg.sendToTarget();
             }
        } else {
            if ((event.getEventType() == VROEMEvent.VREventType.VREventType_ButtonPressed)
                    && (event.getInputId() == VRInputId.VRInputId_System)) {
                Log.d(TAG, "Press system to trigger recenter of controller.");
                triggerRecenter(RecenterType.RecenterType_Controller);
            } else if ((event.getEventType() == VROEMEvent.VREventType.VREventType_DeviceDisconnected)
                            && (event.getDeviceType() == VRDeviceType.VRDeviceType_HMD)) {
                Log.w(TAG, "HMD is disconnected.");
            } else if ((event.getEventType() == VROEMEvent.VREventType.VREventType_DeviceDisconnected)
                && (event.getDeviceType() == VRDeviceType.VRDeviceType_Controller)) {
                Log.w(TAG, "controller is disconnected.");
                showVrScanDialog(false);
            } else if ((event.getEventType() == VROEMEvent.VREventType.VREventType_DeviceConnected)
                && (event.getDeviceType() == VRDeviceType.VRDeviceType_Controller)) {
                Log.w(TAG, "controller is connected.");
                showVrScanDialog(true);
            } else if ((event.getEventType() == VROEMEvent.VREventType.VREventType_ButtonPressed)
                    && (event.getInputId() == VRInputId.VRInputId_Menu)) {
                Log.d(TAG, "Press menu to trigger show dashboard");
                showDashBoard();
            }else if ((event.getEventType() == VROEMEvent.VREventType.VREventType_ButtonPressed)
                    && (event.getDeviceId() == VRTypes.WVR_InputId_Enter)) {
                Log.d(TAG, "Press HMD enter key");
            }else if ((event.getEventType() == VROEMEvent.VREventType.VREventType_ButtonPressed)
                    && (event.getDeviceId() == VRTypes.WVR_InputId_Back)) {
                Log.d(TAG, "Press HMD back key");
            }
        }
    }

    @Override
    public void onAnalogData(int deviceId, VRInputId buttonId, PointF axis, long ticks) {
        Log.d(TAG, "onAnalogData: devId(" + deviceId + "), analogId(" + buttonId.getValue() + "), axis(" + axis.x+", " + axis.y +"), ticks(" + ticks + ")");
     }

    @Override
    public VRValidationResult checkValidation() {
        Log.d(TAG, "checkValidation");
        // Return validation result to server
        return mValidationResult;
    }

    @Override
    public  void notifyVRServerState(VRServerState state) {
        Log.d(TAG, "notifyVRServerState state: " + state);
        mVRServerState = state;
        Message msg = mHandler.obtainMessage(EVENT_CHECK_ENVIRONMENT);
        msg.sendToTarget();
    }

    @Override
    public Bundle getConfigBundle(String key) {
        Log.d(TAG, "getConfigBundle() key: " + key);
        return null;
    }

    @Override
    public String getConfigData(String key) {
        Log.d(TAG, "getConfigData() key: " + key);
        return null;
    }

    @Override
    public boolean setPerformanceLevel(int cpulevel, int gpulevel) {
        Log.d(TAG, "Set PerformanceLevel hasn't been implemented.");
        return false;
    }

    @Override
    public boolean setThreadSchedPolicy(int tid, int policy) {
        Log.d(TAG, "Set ThreadSchedPolicy hasn't been implemented.");
        return false;
    }

    private void doEnvironmentCheck() {
        Log.d(TAG, "doEnvironmentCheck " + mVRServerState);
        if (mVRServerState == VRServerState.VRServerState_RUNNING) {
            if (mValidationResult == null) {
                boolean hasED = hasExternalDisplay();
                mValidationResult = new VRValidationResult(true, hasED, hasED);
            }
        } else {
            if (isHMDConnected()) {
                float fHMDBatteryPercentage = getHmdBatteryPercentage();
                if (fHMDBatteryPercentage < 0.15) {
                    Log.w(TAG, "The battery percentage of HMD is too low.");
                }
                float fHMDTemperature = getHmdBatteryTemperature();
                if (fHMDTemperature > 70) {
                    Log.w(TAG, "The temperature of HMD is too high.");
                }
                int nControllerCount = getConnectedCountrollerCount();
                if (nControllerCount == 0) {
                    Log.w(TAG, "There is no controller.");
                }

                mVRServerState = VRServerState.VRServerState_RUNNING;
                boolean hasED = hasExternalDisplay();
                // VRValidationResult(boolean success, boolean hasExternalDisplay, boolean dimScreen)
                mValidationResult = new VRValidationResult(true, hasED, hasED);
                broadcastServerReady(mValidationResult);

                mHMDHasPSensor = hasProximitySensor();
                if (mHMDHasPSensor) {
                    Log.i(TAG, "HMD supports a proximity sensor.");
                }
            } else {
                // Wait the connection of HMD
                mStartWithoutHMD = true;
                mVRServerState = VRServerState.VRServerState_CHECKING;
            }
        }
    }

    private void showVrScanDialog(boolean bConnected) {
        Log.d(TAG, "showVrScanDialog: " + bConnected);
        Intent intent = new Intent(mOwner, SimpleControllerOverlayService.class);
        intent.putExtra(SimpleControllerOverlayService.CONNECTION_STATE, bConnected);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                mOwner.startForegroundService(intent);
            else
                mOwner.startService(intent);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void showDashBoard(){
        Log.d(TAG, "call showDashBoard");
        Intent intent = new Intent(mOwner, DashboardDemoService.class);
        intent.putExtra("WORK_COMMAND", 1);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                mOwner.startForegroundService(intent);
            else
                mOwner.startService(intent);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
